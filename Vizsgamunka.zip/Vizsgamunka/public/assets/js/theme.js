document.addEventListener("DOMContentLoaded", () => {
    const body = document.body;
    const toggleBtn = document.getElementById("themeToggle");

    function applyTheme(theme) {
        const isLight = theme === "theme-light";
        body.classList.toggle("theme-light", isLight);
        body.classList.toggle("theme-dark", !isLight);

        if (toggleBtn) {
            toggleBtn.textContent = isLight ? "Dark mod" : "Light mod";
        }
    }

    const savedTheme = localStorage.getItem("theme");
    applyTheme(savedTheme === "theme-light" ? "theme-light" : "theme-dark");

    if (toggleBtn) {
        toggleBtn.addEventListener("click", () => {
            const nextTheme = body.classList.contains("theme-light") ? "theme-dark" : "theme-light";
            localStorage.setItem("theme", nextTheme);
            applyTheme(nextTheme);
        });
    }
});
