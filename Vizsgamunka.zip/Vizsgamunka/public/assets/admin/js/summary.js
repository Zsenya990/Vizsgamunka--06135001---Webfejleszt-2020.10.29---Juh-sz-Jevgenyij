const baseUrl = window.APP_CONFIG?.baseUrl || "";

let statusChart = null;
let dailyChart = null;

function shiftMonth(month, offset) {
    const [year, monthNumber] = month.split("-").map(Number);
    const date = new Date(year, monthNumber - 1 + offset, 1);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function updateSummaryUrl() {
    const monthInput = document.getElementById("dailyMonth");
    if (!monthInput) return;

    const url = new URL(window.location.href);
    url.searchParams.set("route", "admin/summary");
    url.searchParams.set("daily_month", monthInput.value);
    window.history.replaceState({}, "", url);
}

function renderStatusChart(data) {
    if (statusChart) statusChart.destroy();
    statusChart = new Chart(document.getElementById("statusChart"), {
        type: "doughnut",
        data: {
            labels: Object.keys(data.by_status),
            datasets: [{
                data: Object.values(data.by_status),
                backgroundColor: [
                    "rgba(13,110,253,0.8)",
                    "rgba(25,135,84,0.8)",
                    "rgba(108,117,125,0.8)",
                    "rgba(220,53,69,0.8)"
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { position: "bottom" } }
        }
    });
}

function renderDailyChart(data) {
    const labels = Object.keys(data.by_day || {});
    if (dailyChart) dailyChart.destroy();
    dailyChart = new Chart(document.getElementById("dailyChart"), {
        type: "line",
        data: {
            labels,
            datasets: [
                {
                    label: "Foglalasok szama",
                    data: labels.map(label => data.by_day?.[label] ?? 0),
                    borderColor: "#0d6efd",
                    backgroundColor: "rgba(13,110,253,0.1)",
                    borderWidth: 3,
                    tension: 0.3
                },
                {
                    label: "Teljesult",
                    data: labels.map(label => data.by_day_completed?.[label] ?? 0),
                    borderColor: "#6c757d",
                    backgroundColor: "rgba(108,117,125,0.12)",
                    borderWidth: 3,
                    tension: 0.3
                },
                {
                    label: "Lemondott",
                    data: labels.map(label => data.by_day_cancelled?.[label] ?? 0),
                    borderColor: "#dc3545",
                    backgroundColor: "rgba(220,53,69,0.12)",
                    borderWidth: 3,
                    tension: 0.3
                }
            ]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0,
                        stepSize: 1
                    }
                }
            }
        }
    });
}

function loadSummary(target = "all") {
    const dailyMonth = document.getElementById("dailyMonth")?.value || new Date().toISOString().slice(0, 7);
    updateSummaryUrl();

    adminFetch(`${baseUrl}/api/dashboard/summary?daily_month=${encodeURIComponent(dailyMonth)}`)
        .then(data => {
            if (target === "all") {
                document.getElementById("totalAppointments").textContent = data.totalAppointments;
                document.getElementById("newAppointments").textContent = data.newAppointments;
                document.getElementById("acceptedAppointments").textContent = data.acceptedAppointments;
                document.getElementById("completedAppointments").textContent = data.completedAppointments ?? 0;
                document.getElementById("rejectedAppointments").textContent = data.rejectedAppointments;
                document.getElementById("freeSlots").textContent = data.freeSlots;
                document.getElementById("bookedSlots").textContent = data.bookedSlots;
                renderStatusChart(data);
            }

            renderDailyChart(data);
        })
        .catch(err => console.error("Hiba a summary betoltesenel:", err));
}

function bindDailyMonthControls() {
    const input = document.getElementById("dailyMonth");
    const prevBtn = document.getElementById("prevDailyMonthBtn");
    const nextBtn = document.getElementById("nextDailyMonthBtn");

    if (input) {
        input.addEventListener("change", () => loadSummary("daily"));
    }

    if (prevBtn && input) {
        prevBtn.addEventListener("click", () => {
            input.value = shiftMonth(input.value, -1);
            loadSummary("daily");
        });
    }

    if (nextBtn && input) {
        nextBtn.addEventListener("click", () => {
            input.value = shiftMonth(input.value, 1);
            loadSummary("daily");
        });
    }
}

document.addEventListener("DOMContentLoaded", () => {
    bindDailyMonthControls();
    loadSummary("all");
});
