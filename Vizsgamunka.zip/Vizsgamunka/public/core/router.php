<?php

declare(strict_types=1);

class Router
{
    private array $routes = [];

    public function get(string $path, callable|array|string $action): void
    {
        $this->routes['GET'][$this->normalizePath($path)] = $action;
    }

    public function post(string $path, callable|array|string $action): void
    {
        $this->routes['POST'][$this->normalizePath($path)] = $action;
    }

    public function put(string $path, callable|array|string $action): void
    {
        $this->routes['PUT'][$this->normalizePath($path)] = $action;
    }

    public function patch(string $path, callable|array|string $action): void
    {
        $this->routes['PATCH'][$this->normalizePath($path)] = $action;
    }

    public function delete(string $path, callable|array|string $action): void
    {
        $this->routes['DELETE'][$this->normalizePath($path)] = $action;
    }

    private function normalizePath(string $path): string
    {
        $path = trim($path);

        if ($path === '' || $path === '/') {
            return '/';
        }

        return trim($path, '/');
    }

    public function run(): void
    {
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        if ($method === 'POST') {
            $override = $_POST['_method'] ?? $_SERVER['HTTP_X_HTTP_METHOD_OVERRIDE'] ?? null;
            if (is_string($override) && $override !== '') {
                $method = strtoupper($override);
            }
        }

        $uri = $this->normalizePath($_GET['route'] ?? '/');

        if (!isset($this->routes[$method]) || empty($this->routes[$method])) {
            $this->render404();
            return;
        }

        $params = [];
        $matchedAction = null;

        foreach ($this->routes[$method] as $route => $action) {
            $pattern = preg_replace('#\{[^/]+\}#', '([^/]+)', $this->normalizePath($route));

            if (preg_match('#^' . $pattern . '$#', $uri, $matches)) {
                array_shift($matches);
                $params = $matches;
                $matchedAction = $action;
                break;
            }
        }

        if ($matchedAction === null) {
            $this->render404();
            return;
        }

        $this->dispatch($matchedAction, $params);
    }

    private function dispatch(callable|array|string $action, array $params = []): void
    {
        if (is_callable($action)) {
            call_user_func_array($action, $params);
            return;
        }

        if (is_array($action)) {
            [$class, $method] = $action;
            $controller = new $class();
            $controller->$method(...$params);
            return;
        }

        if (is_string($action) && str_contains($action, '@')) {
            [$class, $method] = explode('@', $action, 2);
            $controller = new $class();
            $controller->$method(...$params);
            return;
        }

        $this->render404();
    }

    private function render404(): void
    {
        http_response_code(404);
        require __DIR__ . '/../404.php';
    }
}
