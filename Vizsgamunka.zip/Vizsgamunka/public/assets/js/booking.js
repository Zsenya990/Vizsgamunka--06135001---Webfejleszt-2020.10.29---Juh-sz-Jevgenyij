document.addEventListener("DOMContentLoaded", () => {
    const baseUrl = window.APP_CONFIG?.baseUrl || "";
    const form = document.getElementById("bookingForm");
    const errorBox = document.getElementById("bookingErrors");
    const selectedTimeslotInput = document.getElementById("selectedTimeslot");
    const timerPanel = document.getElementById("bookingTimerPanel");
    const timerText = document.getElementById("bookingTimerText");
    const timerHint = document.getElementById("bookingTimerHint");
    const timerClock = document.getElementById("bookingTimerClock");
    const humanCheckQuestion = document.getElementById("humanCheckQuestion");
    const humanAnswerInput = document.getElementById("humanAnswer");

    let countdownInterval = null;
    let availabilityInterval = null;
    let currentExpiresAt = 0;
    let currentDurationSeconds = 300;
    let currentTimeslotId = 0;

    if (!form || !errorBox || !selectedTimeslotInput || !timerPanel || !timerText || !timerHint || !timerClock || !humanCheckQuestion || !humanAnswerInput) {
        return;
    }

    function formatRemaining(totalSeconds) {
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
    }

    function setTimerProgress(progress) {
        timerClock.style.setProperty("--timer-progress", String(Math.max(0, Math.min(1, progress))));
    }

    function showError(message, options = {}) {
        errorBox.innerHTML = `<div>${message}</div>`;
        errorBox.classList.remove("d-none");
    }

    function updateHumanCheck(challenge) {
        if (challenge && typeof challenge.question === "string" && challenge.question.trim() !== "") {
            humanCheckQuestion.textContent = challenge.question;
            humanAnswerInput.value = "";
        }
    }

    function clearTimerVisuals() {
        timerText.textContent = "05:00";
        timerHint.textContent = "5 perced van a foglalas befejezesere.";
        timerClock.classList.remove("expired");
        setTimerProgress(1);
    }

    async function clearServerSelection() {
        try {
            await fetch(`${baseUrl}/api/booking-selection`, { method: "DELETE" });
        } catch (_) {
        }
    }

    async function resetSelection(options = {}) {
        const { notifyServer = false, expired = false, showExpiredAlert = false } = options;

        if (countdownInterval) {
            clearInterval(countdownInterval);
            countdownInterval = null;
        }
        if (availabilityInterval) {
            clearInterval(availabilityInterval);
            availabilityInterval = null;
        }

        currentExpiresAt = 0;
        currentDurationSeconds = 300;
        currentTimeslotId = 0;
        selectedTimeslotInput.value = "";
        humanAnswerInput.value = "";
        form.style.display = "none";
        document.querySelectorAll(".timeslot.selected").forEach(slot => slot.classList.remove("selected"));

        if (expired) {
            timerPanel.classList.remove("d-none");
            timerClock.classList.add("expired");
            timerText.textContent = "00:00";
            timerHint.textContent = "Lejart az idokeret. Kerjuk, valassz ujra idopontot.";
            setTimerProgress(0);
            showError("Lejart az 5 perces foglalasi idokeret. Kerjuk, kezdje ujra a foglalast.");
            if (showExpiredAlert) {
                window.alert("Lejart az 5 perces foglalasi idokeret. Kerjuk, kezdje ujra a foglalast.");
            }
        } else {
            timerPanel.classList.add("d-none");
            clearTimerVisuals();
        }

        if (notifyServer) {
            await clearServerSelection();
        }
    }

    function updateTimer() {
        if (!currentExpiresAt) {
            return;
        }

        const now = Math.floor(Date.now() / 1000);
        const remainingSeconds = Math.max(0, currentExpiresAt - now);

        timerText.textContent = formatRemaining(remainingSeconds);
        timerHint.textContent = remainingSeconds > 0
            ? "Ennyi idod maradt a foglalas befejezesere."
            : "Lejart az idokeret. Kerjuk, valassz ujra idopontot.";
        setTimerProgress(currentDurationSeconds > 0 ? remainingSeconds / currentDurationSeconds : 0);

        if (remainingSeconds <= 0) {
            resetSelection({ notifyServer: true, expired: true, showExpiredAlert: true });
        }
    }

    async function pollTimeslotAvailability() {
        if (!currentTimeslotId) {
            return;
        }

        try {
            const response = await fetch(`${baseUrl}/api/availability/timeslot/${currentTimeslotId}`, {
                cache: "no-store"
            });
            const result = await response.json();

            if (!response.ok || result.available === false) {
                await resetSelection({ notifyServer: false });
                showError("Ez az idopont mar nem erheto el. Kerjuk, valasszon uj idopontot.");
                const emptyState = document.getElementById("timeslotEmptyState");
                if (emptyState) {
                    emptyState.textContent = "A kivalasztott idopont idokozben foglaltta valt. Kerjuk, valasszon masikat.";
                }
            }
        } catch (_) {
        }
    }

    function startTimer(timeslotId, expiresAt, durationSeconds) {
        if (countdownInterval) {
            clearInterval(countdownInterval);
        }
        if (availabilityInterval) {
            clearInterval(availabilityInterval);
        }

        currentTimeslotId = timeslotId;
        currentExpiresAt = expiresAt;
        currentDurationSeconds = durationSeconds > 0 ? durationSeconds : 300;
        timerPanel.classList.remove("d-none");
        timerClock.classList.remove("expired");
        errorBox.classList.add("d-none");
        errorBox.innerHTML = "";
        updateTimer();
        countdownInterval = setInterval(updateTimer, 1000);
        availabilityInterval = setInterval(pollTimeslotAvailability, 5000);
    }

    document.addEventListener("booking:selection-started", event => {
        const timeslotId = Number(event.detail?.timeslotId || 0);
        const expiresAt = Number(event.detail?.expiresAt || 0);
        const durationSeconds = Number(event.detail?.durationSeconds || 300);
        updateHumanCheck(event.detail?.humanCheck || null);
        if (timeslotId > 0 && expiresAt > 0) {
            startTimer(timeslotId, expiresAt, durationSeconds);
        }
    });

    document.addEventListener("booking:selection-cleared", () => {
        resetSelection({ notifyServer: false });
    });

    form.addEventListener("submit", async (event) => {
        event.preventDefault();

        errorBox.classList.add("d-none");
        errorBox.innerHTML = "";

        if (!humanAnswerInput.value.trim()) {
            showError("Kerjuk, valaszoljon a biztonsagi kerdesre.");
            return;
        }

        try {
            const response = await fetch(`${baseUrl}/api/appointments`, {
                method: "POST",
                body: new FormData(form)
            });

            const result = await response.json();
            if (result.success) {
                await resetSelection({ notifyServer: false });
                window.location.href = result.redirect || `${baseUrl}/siker`;
                return;
            }

            if (result.error === "selection_expired" || result.error === "selection_missing") {
                await resetSelection({ notifyServer: false, expired: true });
                return;
            }

            if (result.error === "timeslot_unavailable") {
                await resetSelection({ notifyServer: false });
            }

            const messages = result.errors || [result.message || result.error || "Ismeretlen hiba tortent."];
            errorBox.innerHTML = messages.map(message => `<div>${message}</div>`).join("");
            errorBox.classList.remove("d-none");
            updateHumanCheck(result.humanCheck);
        } catch (error) {
            errorBox.textContent = "A foglalas kuldese sikertelen volt.";
            errorBox.classList.remove("d-none");
        }
    });

    window.addEventListener("pagehide", () => {
        if (currentTimeslotId > 0) {
            fetch(`${baseUrl}/api/booking-selection`, {
                method: "DELETE",
                keepalive: true
            }).catch(() => {});
        }
    });
});
