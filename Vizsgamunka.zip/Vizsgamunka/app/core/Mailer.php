<?php

declare(strict_types=1);

namespace App\Core;

final class Mailer
{
    public static function sendAppointmentRescheduled(string $toEmail, string $name, string $oldTimeslot, string $newTimeslot): bool
    {
        if ($toEmail === '' || !filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        $subject = 'Idopontmodositas ertesito';
        $displayName = $name !== '' ? $name : 'Foglalo';
        $from = 'no-reply@localhost';

        $message = implode("\r\n", [
            'Kedves ' . $displayName . '!',
            '',
            'Az idopontfoglalasod modositva lett.',
            'Korabbi idopont: ' . ($oldTimeslot !== '' ? $oldTimeslot : '-'),
            'Uj idopont: ' . ($newTimeslot !== '' ? $newTimeslot : '-'),
            '',
            'Ha kerdesed van, kerlek vedd fel velunk a kapcsolatot.',
        ]);

        $headers = [
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=UTF-8',
            'From: Vizsgamunka <' . $from . '>',
        ];

        return mail($toEmail, '=?UTF-8?B?' . base64_encode($subject) . '?=', $message, implode("\r\n", $headers));
    }
}
