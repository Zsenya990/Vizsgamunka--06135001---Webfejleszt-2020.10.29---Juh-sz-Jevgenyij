<?php

declare(strict_types=1);

namespace App\Core;

use Throwable;

final class ErrorHandler
{
    public static function register(): void
    {
        set_error_handler([self::class, 'handleError']);
        set_exception_handler([self::class, 'handleException']);
        register_shutdown_function([self::class, 'handleShutdown']);
    }

    public static function handleError(int $severity, string $message, string $file, int $line): bool
    {
        if (!(error_reporting() & $severity)) {
            return false;
        }

        throw new \ErrorException($message, 0, $severity, $file, $line);
    }

    public static function handleException(Throwable $exception): void
    {
        $statusCode = $exception instanceof HttpException ? $exception->statusCode() : 500;
        self::respond($statusCode, $exception);
    }

    public static function handleShutdown(): void
    {
        $error = error_get_last();
        if ($error === null) {
            return;
        }

        $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR];
        if (!in_array($error['type'] ?? 0, $fatalTypes, true)) {
            return;
        }

        $exception = new \ErrorException(
            (string) ($error['message'] ?? 'Fatal error'),
            0,
            (int) ($error['type'] ?? E_ERROR),
            (string) ($error['file'] ?? ''),
            (int) ($error['line'] ?? 0)
        );

        self::respond(500, $exception);
    }

    private static function respond(int $statusCode, Throwable $exception): void
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        error_log(sprintf(
            '[Vizsgamunka] %s: %s in %s:%d',
            $exception::class,
            $exception->getMessage(),
            $exception->getFile(),
            $exception->getLine()
        ));
        Logger::error('system', 'Unhandled exception', [
            'type' => $exception::class,
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'status_code' => $statusCode,
        ]);

        if (headers_sent() === false) {
            http_response_code($statusCode);
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');
        }

        $isApi = self::isApiRequest();
        $debug = (bool) Config::get('APP_DEBUG', false);

        if ($isApi) {
            if (headers_sent() === false) {
                header('Content-Type: application/json; charset=utf-8');
            }

            $payload = [
                'error' => $statusCode === 404 ? 'not_found' : 'internal_server_error',
                'message' => $statusCode === 404 ? 'A keresett eroforras nem talalhato.' : 'Varatlan hiba tortent.',
            ];

            if ($debug) {
                $payload['debug'] = [
                    'type' => $exception::class,
                    'message' => $exception->getMessage(),
                    'file' => $exception->getFile(),
                    'line' => $exception->getLine(),
                ];
            }

            echo json_encode($payload, JSON_UNESCAPED_UNICODE);
            return;
        }

        $message = $debug ? $exception->getMessage() : ($statusCode === 404 ? 'A keresett oldal nem talalhato.' : 'Varatlan hiba tortent.');
        $page = $statusCode === 404 ? '/public/404.php' : '/public/500.php';
        require dirname(__DIR__, 2) . $page;
    }

    private static function isApiRequest(): bool
    {
        $route = trim((string) ($_GET['route'] ?? ''), '/');
        return str_starts_with($route, 'api/');
    }
}
