<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Validator;

class HomeController extends BaseController
{
    public function index(): void
    {
        $this->render('home/index', [
            'title' => 'Vizsgamunka - Idopontfoglalas',
            'pageScripts' => [
                asset_url('public/assets/js/home.js'),
            ],
        ]);
    }

    public function contact(): void
    {
        $this->render('public/contact', [
            'title' => 'Kapcsolat',
            'csrfToken' => $this->csrfToken('contact_csrf_token'),
            'old' => [
                'name' => '',
                'email' => '',
                'message' => '',
            ],
        ]);
    }

    public function contactSubmit(): void
    {
        $name = trim((string) ($_POST['name'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));
        $message = trim((string) ($_POST['message'] ?? ''));
        $old = [
            'name' => $name,
            'email' => $email,
            'message' => $message,
        ];

        $csrfToken = (string) ($_POST['csrf_token'] ?? '');
        if (!$this->validateCsrfToken($csrfToken, 'contact_csrf_token')) {
            $this->render('public/contact', [
                'title' => 'Kapcsolat',
                'error' => 'Ervenytelen kereskuldes. Probald ujra.',
                'csrfToken' => $this->csrfToken('contact_csrf_token'),
                'old' => $old,
            ]);
            return;
        }

        $errors = [];
        if (!Validator::required($name) || mb_strlen($name) < 3) {
            $errors[] = 'A nev legalabb 3 karakter legyen.';
        }
        if (!Validator::maxLength($name, 150)) {
            $errors[] = 'A nev legfeljebb 150 karakter lehet.';
        }
        if (!Validator::required($email) || !Validator::email($email)) {
            $errors[] = 'Ervenytelen e-mail cim.';
        }
        if (!Validator::maxLength($email, 190)) {
            $errors[] = 'Az e-mail cim tul hosszu.';
        }
        if (!Validator::required($message) || mb_strlen($message) < 5) {
            $errors[] = 'Az uzenet legalabb 5 karakter legyen.';
        }
        if (!Validator::maxLength($message, 2000)) {
            $errors[] = 'Az uzenet legfeljebb 2000 karakter lehet.';
        }

        if ($errors !== []) {
            $this->render('public/contact', [
                'title' => 'Kapcsolat',
                'errors' => $errors,
                'csrfToken' => $this->csrfToken('contact_csrf_token'),
                'old' => $old,
            ]);
            return;
        }

        $this->render('public/contact', [
            'title' => 'Kapcsolat',
            'sent' => true,
            'csrfToken' => $this->csrfToken('contact_csrf_token'),
            'old' => [
                'name' => '',
                'email' => '',
                'message' => '',
            ],
        ]);
    }

    public function success(): void
    {
        $this->render('public/success', [
            'title' => 'Sikeres foglalas',
        ]);
    }
}
