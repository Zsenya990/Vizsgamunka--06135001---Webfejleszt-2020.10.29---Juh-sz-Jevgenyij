<?php if (empty($appointment)): ?>
    <div class="p-4">
        <div class="alert alert-danger mb-0">A kert foglalas nem talalhato.</div>
    </div>
<?php else: ?>
    <?php
    $currentStatus = trim((string) ($appointment['allapot'] ?? ''));
    $currentStatus = strtolower(str_replace(['Ú', 'ú', 'í', 'ö', 'ő'], ['U', 'u', 'i', 'o', 'o'], $currentStatus));
    $labelMap = [
        'uj' => 'Uj',
        'elfogadva' => 'Elfogadva',
        'teljesult' => 'Teljesult',
        'torolve' => 'Torolve',
    ];
    ?>
    <div class="modal-header">
        <h5 class="modal-title">Statusz modositasa (#<?= (int) $appointment['id'] ?>)</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body">
        <select id="statusSelect" class="form-select">
            <?php foreach ($allowedStatuses as $status): ?>
                <option value="<?= htmlspecialchars($status, ENT_QUOTES, 'UTF-8') ?>"<?= $currentStatus === $status ? ' selected' : '' ?>>
                    <?= htmlspecialchars($labelMap[$status] ?? $status, ENT_QUOTES, 'UTF-8') ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="saveStatusBtn" data-appointment-id="<?= (int) $appointment['id'] ?>">Mentes</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Megse</button>
    </div>
<?php endif; ?>
