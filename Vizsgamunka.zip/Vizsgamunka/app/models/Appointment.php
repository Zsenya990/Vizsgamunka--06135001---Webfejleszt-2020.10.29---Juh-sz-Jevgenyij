<?php

declare(strict_types=1);

namespace App\Models;

class Appointment extends BaseModel
{
    public function create(string $name, string $email, string $phone, string $message, int $timeslotId): bool
    {
        return $this->createAndReserveTimeslot($name, $email, $phone, $message, $timeslotId) !== false;
    }

    public function createAndGetId(string $name, string $email, string $phone, string $message, int $timeslotId): int|false
    {
        return $this->createAndReserveTimeslot($name, $email, $phone, $message, $timeslotId);
    }

    public function getAll(): array
    {
        return $this->fetchAll(
            "SELECT a.*, t.timeslot
             FROM appointments a
             LEFT JOIN timeslots t ON a.timeslot_id = t.id
             ORDER BY t.timeslot DESC, a.created_at DESC"
        );
    }

    public function getFiltered(string $status = '', string $month = ''): array
    {
        $sql = "
            SELECT a.*, t.timeslot
            FROM appointments a
            LEFT JOIN timeslots t ON a.timeslot_id = t.id
            WHERE 1
        ";
        $params = [];

        if ($status !== '') {
            $sql .= " AND a.allapot = ? ";
            $params[] = $status;
        }

        if ($month !== '') {
            $sql .= " AND DATE_FORMAT(t.timeslot, '%Y-%m') = ? ";
            $params[] = $month;
        }

        $sql .= " ORDER BY t.timeslot DESC, a.created_at DESC";

        return $this->fetchAll($sql, $params);
    }

    public function getById(int $id): array|false
    {
        return $this->fetch(
            "SELECT a.*, t.timeslot
             FROM appointments a
             LEFT JOIN timeslots t ON a.timeslot_id = t.id
             WHERE a.id = ?",
            [$id]
        );
    }

    public function updateStatus(int $id, string $status): bool
    {
        return $this->executeQuery("UPDATE appointments SET allapot = ? WHERE id = ?", [$status, $id]);
    }

    public function reschedule(int $id, int $newTimeslotId): array
    {
        $appointment = $this->fetch(
            "SELECT a.*, t.timeslot
             FROM appointments a
             LEFT JOIN timeslots t ON a.timeslot_id = t.id
             WHERE a.id = ?",
            [$id]
        );

        if (!$appointment) {
            return ['success' => false, 'error' => 'appointment_not_found'];
        }

        if ((int) $appointment['timeslot_id'] === $newTimeslotId) {
            return [
                'success' => true,
                'appointment' => $appointment,
                'old_timeslot' => (string) ($appointment['timeslot'] ?? ''),
                'new_timeslot' => (string) ($appointment['timeslot'] ?? ''),
                'changed' => false,
            ];
        }

        $newTimeslot = $this->fetch("SELECT id, timeslot, is_booked FROM timeslots WHERE id = ?", [$newTimeslotId]);
        if (!$newTimeslot) {
            return ['success' => false, 'error' => 'timeslot_not_found'];
        }

        if ((int) $newTimeslot['is_booked'] === 1) {
            return ['success' => false, 'error' => 'timeslot_unavailable'];
        }

        $this->pdo->beginTransaction();

        try {
            $reserveNew = $this->run(
                "UPDATE timeslots
                 SET is_booked = 1
                 WHERE id = ?
                   AND is_booked = 0",
                [$newTimeslotId]
            );

            if ($reserveNew->rowCount() !== 1) {
                $this->pdo->rollBack();
                return ['success' => false, 'error' => 'timeslot_unavailable'];
            }

            $this->executeQuery("UPDATE appointments SET timeslot_id = ? WHERE id = ?", [$newTimeslotId, $id]);
            $this->executeQuery("UPDATE timeslots SET is_booked = 0 WHERE id = ?", [(int) $appointment['timeslot_id']]);
            $this->pdo->commit();
        } catch (\Throwable $throwable) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $throwable;
        }

        $updatedAppointment = $this->getById($id);

        return [
            'success' => true,
            'appointment' => $updatedAppointment ?: $appointment,
            'old_timeslot' => (string) ($appointment['timeslot'] ?? ''),
            'new_timeslot' => (string) ($newTimeslot['timeslot'] ?? ''),
            'changed' => true,
        ];
    }

    public function delete(int $id): bool
    {
        $appointment = $this->fetch("SELECT timeslot_id FROM appointments WHERE id = ?", [$id]);
        if (!$appointment) {
            return false;
        }

        $this->pdo->beginTransaction();

        try {
            $this->executeQuery("DELETE FROM appointments WHERE id = ?", [$id]);
            $this->executeQuery("UPDATE timeslots SET is_booked = 0 WHERE id = ?", [(int) $appointment['timeslot_id']]);
            $this->pdo->commit();
            return true;
        } catch (\Throwable $throwable) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $throwable;
        }
    }

    public function getSummaryData(array $allowedStatuses, array $slotCounts, ?string $dailyMonth = null): array
    {
        $statusRows = $this->fetchAll(
            "SELECT allapot, COUNT(*) AS total
             FROM appointments
             GROUP BY allapot"
        );

        $byStatus = array_fill_keys($allowedStatuses, 0);
        foreach ($statusRows as $row) {
            $normalizedStatus = $this->normalizeStatus((string) $row['allapot']);
            if (!isset($byStatus[$normalizedStatus])) {
                $byStatus[$normalizedStatus] = 0;
            }
            $byStatus[$normalizedStatus] += (int) $row['total'];
        }

        $dailySql = "
            SELECT DATE(t.timeslot) AS day, a.allapot, COUNT(*) AS total
            FROM appointments a
            LEFT JOIN timeslots t ON a.timeslot_id = t.id
        ";
        $dailyParams = [];
        if ($dailyMonth !== null && preg_match('/^\d{4}-\d{2}$/', $dailyMonth) === 1) {
            $dailySql .= " WHERE DATE_FORMAT(t.timeslot, '%Y-%m') = ? ";
            $dailyParams[] = $dailyMonth;
        }
        $dailySql .= " GROUP BY DATE(t.timeslot), a.allapot ORDER BY day ASC";

        $dailyRows = $this->fetchAll($dailySql, $dailyParams);

        $byDay = [];
        $byDayCompleted = [];
        $byDayCancelled = [];

        if ($dailyMonth !== null && preg_match('/^\d{4}-\d{2}$/', $dailyMonth) === 1) {
            $start = new \DateTimeImmutable($dailyMonth . '-01');
            $end = $start->modify('last day of this month');

            for ($date = $start; $date <= $end; $date = $date->modify('+1 day')) {
                $dayKey = $date->format('Y-m-d');
                $byDay[$dayKey] = 0;
                $byDayCompleted[$dayKey] = 0;
                $byDayCancelled[$dayKey] = 0;
            }
        }

        foreach ($dailyRows as $row) {
            $day = (string) $row['day'];
            $status = $this->normalizeStatus((string) $row['allapot']);
            $total = (int) $row['total'];

            if (!isset($byDay[$day])) {
                $byDay[$day] = 0;
                $byDayCompleted[$day] = 0;
                $byDayCancelled[$day] = 0;
            }

            $byDay[$day] += $total;

            if ($status === 'teljesult') {
                $byDayCompleted[$day] += $total;
            }

            if ($status === 'torolve') {
                $byDayCancelled[$day] += $total;
            }
        }

        return [
            'totalAppointments' => (int) $this->fetchColumn("SELECT COUNT(*) FROM appointments"),
            'newAppointments' => $byStatus['uj'] ?? 0,
            'acceptedAppointments' => $byStatus['elfogadva'] ?? 0,
            'completedAppointments' => $byStatus['teljesult'] ?? 0,
            'rejectedAppointments' => $byStatus['torolve'] ?? 0,
            'freeSlots' => $slotCounts['free'],
            'bookedSlots' => $slotCounts['booked'],
            'by_status' => $byStatus,
            'by_day' => $byDay,
            'by_day_completed' => $byDayCompleted,
            'by_day_cancelled' => $byDayCancelled,
            'dailyMonth' => $dailyMonth,
        ];
    }

    public function getChartData(string $freeMonth, string $weeklyMonth, string $monthlyYear, array $slotCounts): array
    {
        $weeklyMonthStart = $weeklyMonth . '-01';
        $weeklyMonthEnd = date('Y-m-d', strtotime($weeklyMonthStart . ' +1 month'));

        $weekly = $this->fetchAll(
            "SELECT
                DATE_FORMAT(DATE_SUB(DATE(t.timeslot), INTERVAL WEEKDAY(t.timeslot) DAY), '%Y-%m-%d') AS week_start,
                COUNT(*) AS count
             FROM appointments a
             JOIN timeslots t ON a.timeslot_id = t.id
             WHERE t.timeslot >= ?
               AND t.timeslot < ?
             GROUP BY week_start
             ORDER BY week_start ASC",
            [$weeklyMonthStart, $weeklyMonthEnd]
        );

        $monthly = $this->fetchAll(
            "SELECT DATE_FORMAT(t.timeslot, '%Y-%m') AS month, COUNT(*) AS count
             FROM appointments a
             JOIN timeslots t ON a.timeslot_id = t.id
             WHERE YEAR(t.timeslot) = ?
             GROUP BY DATE_FORMAT(t.timeslot, '%Y-%m')
             ORDER BY month ASC",
            [$monthlyYear]
        );

        $totalSlotsMonth = $slotCounts['total'];
        $bookedSlotsMonth = $slotCounts['booked'];
        $freeSlotsMonth = $totalSlotsMonth - $bookedSlotsMonth;
        $freePercent = $totalSlotsMonth > 0 ? round(($freeSlotsMonth / $totalSlotsMonth) * 100, 2) : 0;

        return [
            'freeMonth' => $freeMonth,
            'weeklyMonth' => $weeklyMonth,
            'monthlyYear' => $monthlyYear,
            'weekly' => $weekly,
            'monthly' => $monthly,
            'totalSlotsMonth' => $totalSlotsMonth,
            'bookedSlotsMonth' => $bookedSlotsMonth,
            'freeSlotsMonth' => $freeSlotsMonth,
            'monthlyFreePercent' => $freePercent,
            'monthlyBookedPercent' => $totalSlotsMonth > 0 ? round(100 - $freePercent, 2) : 0,
        ];
    }

    public function getExportData(string $status, string $month): array
    {
        $sql = "
            SELECT
                a.id,
                a.name,
                a.email,
                a.phone,
                a.message,
                a.allapot,
                t.timeslot,
                a.created_at
            FROM appointments a
            LEFT JOIN timeslots t ON a.timeslot_id = t.id
            WHERE 1
        ";
        $params = [];

        if ($status !== '') {
            $sql .= " AND a.allapot = ? ";
            $params[] = $status;
        }

        if ($month !== '') {
            $sql .= " AND DATE_FORMAT(t.timeslot, '%Y-%m') = ? ";
            $params[] = $month;
        }

        $sql .= " ORDER BY a.created_at DESC";

        return $this->fetchAll($sql, $params, \PDO::FETCH_NUM);
    }

    private function createAndReserveTimeslot(string $name, string $email, string $phone, string $message, int $timeslotId): int|false
    {
        $this->pdo->beginTransaction();

        try {
            $reserve = $this->run(
                "UPDATE timeslots
                 SET is_booked = 1
                 WHERE id = ?
                   AND is_booked = 0",
                [$timeslotId]
            );

            if ($reserve->rowCount() !== 1) {
                $this->pdo->rollBack();
                return false;
            }

            $created = $this->executeQuery(
                "INSERT INTO appointments (name, email, phone, message, timeslot_id, allapot, created_at)
                 VALUES (?, ?, ?, ?, ?, 'elfogadva', NOW())",
                [$name, $email, $phone, $message, $timeslotId]
            );

            if (!$created) {
                $this->pdo->rollBack();
                return false;
            }

            $appointmentId = (int) $this->pdo->lastInsertId();
            $this->pdo->commit();

            return $appointmentId > 0 ? $appointmentId : false;
        } catch (\Throwable $throwable) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $throwable;
        }
    }

    private function normalizeStatus(string $status): string
    {
        $status = $this->normalizeText($status);
        $map = [
            'uj' => 'uj',
            'elfogadva' => 'elfogadva',
            'teljesult' => 'teljesult',
            'elutasitva' => 'torolve',
            'torolve' => 'torolve',
        ];

        return $map[$status] ?? $status;
    }

    private function normalizeText(string $value): string
    {
        $value = strtolower(trim($value));
        $transliterated = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if ($transliterated !== false) {
            $value = strtolower($transliterated);
        }

        return preg_replace('/[^a-z0-9]+/', '', $value) ?? $value;
    }
}
