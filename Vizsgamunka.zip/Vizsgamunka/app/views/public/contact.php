<div class="card shadow p-4">
    <h1 class="text-center mb-4">Kapcsolat</h1>

    <?php if (!empty($sent)): ?>
        <div class="alert alert-success">Uzenetedet rogzitettuk. Koszonjuk.</div>
    <?php endif; ?>

    <form method="post" action="<?= htmlspecialchars(app_url('kapcsolat'), ENT_QUOTES, 'UTF-8') ?>">

        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string) ($csrfToken ?? ''), ENT_QUOTES, 'UTF-8') ?>">

        <div class="mb-3">
            <label class="form-label" for="contactName">Nev</label>
            <input id="contactName" type="text" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label" for="contactEmail">E-mail cim</label>
            <input id="contactEmail" type="email" name="email" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label" for="contactMessage">Uzenet</label>
            <textarea id="contactMessage" name="message" class="form-control" rows="5" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary w-100">Uzenet kuldese</button>
    </form>
</div>