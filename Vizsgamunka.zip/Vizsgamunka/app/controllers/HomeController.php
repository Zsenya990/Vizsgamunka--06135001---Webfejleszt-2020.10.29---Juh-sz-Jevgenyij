<?php

declare(strict_types=1);

namespace App\Controllers;

class HomeController extends BaseController
{
    public function index(): void
    {
        $this->render('home/index', [
            'title' => 'Vizsgamunka - Idopontfoglalas',
            'pageScripts' => [
                asset_url('public/assets/js/home.js'),
            ],
        ]);
    }

    public function contact(): void
    {
        $this->render('public/contact', [
            'title' => 'Kapcsolat',
            'csrfToken' => $this->csrfToken('contact_csrf_token'),
        ]);
    }

    public function contactSubmit(): void
    {
        $csrfToken = (string) ($_POST['csrf_token'] ?? '');
        if (!$this->validateCsrfToken($csrfToken, 'contact_csrf_token')) {
            $this->render('public/contact', [
                'title' => 'Kapcsolat',
                'error' => 'Ervenytelen kereskuldes. Probald ujra.',
                'csrfToken' => $this->csrfToken('contact_csrf_token'),
            ]);
            return;
        }

        $this->render('public/contact', [
            'title' => 'Kapcsolat',
            'sent' => true,
            'csrfToken' => $this->csrfToken('contact_csrf_token'),
        ]);
    }

    public function success(): void
    {
        $this->render('public/success', [
            'title' => 'Sikeres foglalas',
        ]);
    }
}
