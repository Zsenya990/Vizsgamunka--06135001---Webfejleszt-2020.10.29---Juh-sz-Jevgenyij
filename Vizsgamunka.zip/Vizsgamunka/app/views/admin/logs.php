<?php
$filters = $filters ?? ['category' => '', 'level' => '', 'date' => ''];
$entries = $entries ?? [];
$categories = $categories ?? [];
$levels = $levels ?? [];
$stats = $stats ?? [];
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
    <div>
        <h2 class="fw-bold mb-1">Rendszerlogok</h2>
        <p class="text-muted mb-0">Kategorizalt es exportalhato naplozas.</p>
    </div>
    <a class="btn btn-outline-light" href="<?= htmlspecialchars(app_url('admin/export/logs') . '?' . http_build_query($filters), ENT_QUOTES, 'UTF-8') ?>">
        <i class="bi bi-download me-2"></i>CSV export
    </a>
</div>

<div class="row g-3 mb-4">
    <?php foreach ($stats as $category => $count): ?>
        <div class="col-md-3 col-sm-6">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <div class="text-uppercase small text-muted"><?= htmlspecialchars((string) $category, ENT_QUOTES, 'UTF-8') ?></div>
                    <div class="fs-3 fw-bold"><?= (int) $count ?></div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(app_url('admin/logs'), ENT_QUOTES, 'UTF-8') ?>" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label" for="logCategory">Kategoria</label>
                <select id="logCategory" name="category" class="form-select">
                    <option value="">Mind</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= htmlspecialchars((string) $category, ENT_QUOTES, 'UTF-8') ?>"<?= ($filters['category'] ?? '') === $category ? ' selected' : '' ?>>
                            <?= htmlspecialchars((string) $category, ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label" for="logLevel">Szint</label>
                <select id="logLevel" name="level" class="form-select">
                    <option value="">Mind</option>
                    <?php foreach ($levels as $level): ?>
                        <option value="<?= htmlspecialchars((string) $level, ENT_QUOTES, 'UTF-8') ?>"<?= ($filters['level'] ?? '') === $level ? ' selected' : '' ?>>
                            <?= htmlspecialchars((string) $level, ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label" for="logDate">Datum</label>
                <input id="logDate" type="date" name="date" class="form-control" value="<?= htmlspecialchars((string) ($filters['date'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
            </div>
            <div class="col-md-2 d-grid">
                <button type="submit" class="btn btn-primary">Szures</button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead>
                    <tr>
                        <th>Idopont</th>
                        <th>Szint</th>
                        <th>Kategoria</th>
                        <th>Uzenet</th>
                        <th>IP</th>
                        <th>Context</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($entries === []): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">Nincs megjelenitheto logbejegyzes.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($entries as $entry): ?>
                            <tr>
                                <td><?= htmlspecialchars((string) ($entry['timestamp'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                                <td><span class="badge text-bg-dark"><?= htmlspecialchars((string) ($entry['level'] ?? ''), ENT_QUOTES, 'UTF-8') ?></span></td>
                                <td><?= htmlspecialchars((string) ($entry['category'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                                <td><?= htmlspecialchars((string) ($entry['message'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                                <td><?= htmlspecialchars((string) ($entry['ip'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                                <td><code><?= htmlspecialchars(json_encode($entry['context'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8') ?></code></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
