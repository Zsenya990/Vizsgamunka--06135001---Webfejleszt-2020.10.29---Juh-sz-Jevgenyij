<?php
$pageTitle = $title ?? 'Vizsgamunka - Idopontfoglalas';
$currentRoute = trim((string) ($_GET['route'] ?? '/'), '/');
$pageScripts = $pageScripts ?? [];
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= htmlspecialchars(asset_url('public/assets/css/public.css'), ENT_QUOTES, 'UTF-8') ?>">
</head>
<body class="theme-dark" data-app-section="public">
<header class="public-header shadow-sm">
    <div class="container d-flex justify-content-between align-items-center py-3">
        <a href="<?= htmlspecialchars(app_url(), ENT_QUOTES, 'UTF-8') ?>" class="site-title">Vizsgamunka - Idopontfoglalas</a>
        <div class="d-flex align-items-center gap-3">
            <nav class="public-nav d-flex gap-3">
                <a href="<?= htmlspecialchars(app_url(), ENT_QUOTES, 'UTF-8') ?>"<?= $currentRoute === '' ? ' aria-current="page"' : '' ?>>Kezdolap</a>
                <a href="<?= htmlspecialchars(app_url('kapcsolat'), ENT_QUOTES, 'UTF-8') ?>"<?= $currentRoute === 'kapcsolat' ? ' aria-current="page"' : '' ?>>Kapcsolat</a>
            </nav>
            <button id="themeToggle" class="theme-toggle-btn" type="button">Dark mod</button>
            <?php if (!empty($_SESSION['admin_logged_in'])): ?>
                <a href="<?= htmlspecialchars(app_url('admin'), ENT_QUOTES, 'UTF-8') ?>" class="btn btn-success">Admin</a>
            <?php else: ?>
                <a href="<?= htmlspecialchars(app_url('admin/login'), ENT_QUOTES, 'UTF-8') ?>" class="btn btn-dark">Admin</a>
            <?php endif; ?>
        </div>
    </div>
</header>

<main class="container mt-5">
    <?= $content ?>
</main>

<footer>
    <p>&copy; <?= date('Y') ?> Idopontfoglalas rendszer</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
window.APP_CONFIG = {
    baseUrl: <?= json_encode(APP_BASE_PATH, JSON_UNESCAPED_UNICODE) ?>
};
</script>
<script src="<?= htmlspecialchars(asset_url('public/assets/js/theme.js'), ENT_QUOTES, 'UTF-8') ?>"></script>
<?php foreach ($pageScripts as $script): ?>
    <script src="<?= htmlspecialchars($script, ENT_QUOTES, 'UTF-8') ?>"></script>
<?php endforeach; ?>
</body>
</html>
