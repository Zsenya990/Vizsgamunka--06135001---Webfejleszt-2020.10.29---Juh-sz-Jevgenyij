<div class="card shadow p-5 text-center">
    <h1 class="mb-3">Sikeres foglalas</h1>
    <p class="lead mb-4">A foglalasod rogzitettuk. Hamarosan jelentkezunk a reszletekkel.</p>
    <a href="<?= htmlspecialchars(app_url(), ENT_QUOTES, 'UTF-8') ?>" class="btn btn-primary">Vissza a kezdolapra</a>
</div>
