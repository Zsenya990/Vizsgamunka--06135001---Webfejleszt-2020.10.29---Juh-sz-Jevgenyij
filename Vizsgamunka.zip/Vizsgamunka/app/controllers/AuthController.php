<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\LoginThrottle;
use App\Core\Logger;
use App\Models\Admin;

class AuthController extends BaseController
{
    private Admin $admin;

    public function __construct()
    {
        $this->admin = new Admin();
    }

    public function adminLogin(): void
    {
        $this->guestOnly();

        $this->render('auth/admin_login', [
            'title' => 'Admin bejelentkezes',
            'error' => !empty($_GET['error']),
            'timedOut' => !empty($_GET['timeout']),
            'lockedOut' => !empty($_GET['locked']),
            'csrfToken' => $this->csrfToken('admin_login_csrf_token'),
        ], 'auth');
    }

    public function adminLoginPost(): void
    {
        $this->guestOnly();

        $csrfToken = (string) ($_POST['csrf_token'] ?? '');
        if (!$this->validateCsrfToken($csrfToken, 'admin_login_csrf_token')) {
            $this->redirect('/admin/login?error=1');
        }

        $throttleKey = $this->loginThrottleKey();
        if (LoginThrottle::isLocked($throttleKey)) {
            Logger::warning('auth', 'Blocked admin login attempt during lockout', [
                'username' => $_POST['username'] ?? '',
            ]);
            $this->redirect('/admin/login?locked=1');
        }

        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');

        if ($this->admin->verifyPassword($username, $password)) {
            session_regenerate_id(true);

            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $username;
            $_SESSION['admin_ip'] = $_SERVER['REMOTE_ADDR'] ?? '';
            $_SESSION['admin_ua'] = $_SERVER['HTTP_USER_AGENT'] ?? '';
            $_SESSION['last_activity'] = time();
            $_SESSION['last_regeneration'] = time();
            $_SESSION['admin_csrf_token'] = bin2hex(random_bytes(32));

            LoginThrottle::clear($throttleKey);
            Logger::info('auth', 'Admin login successful', ['username' => $username]);
            $this->redirect('/admin');
        }

        LoginThrottle::recordFailure($throttleKey);
        Logger::warning('auth', 'Admin login failed', ['username' => $username]);
        if (LoginThrottle::isLocked($throttleKey)) {
            Logger::warning('auth', 'Admin login locked', ['username' => $username]);
            $this->redirect('/admin/login?locked=1');
        }

        $this->redirect('/admin/login?error=1');
    }

    public function adminLogout(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirect('/admin');
        }

        $csrfToken = (string) ($_POST['csrf_token'] ?? '');
        if (!$this->validateCsrfToken($csrfToken, 'admin_csrf_token')) {
            $this->redirect('/admin');
        }

        Logger::info('auth', 'Admin logout', ['username' => $_SESSION['admin_username'] ?? '']);
        $this->logoutAdmin();
        $this->redirect('/');
    }

    private function loginThrottleKey(): string
    {
        return (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    }
}
