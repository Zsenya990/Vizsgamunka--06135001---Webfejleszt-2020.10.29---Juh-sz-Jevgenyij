<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold">Idopontok kezelese</h2>
        <p class="text-muted">Idopontok generalasa, szerkesztese es torlese</p>
    </div>

    <button class="btn btn-secondary d-flex align-items-center gap-2" id="refreshTimeslotsBtn" type="button">
        <span id="refreshIcon"><i class="bi bi-arrow-clockwise"></i></span>
        <span id="refreshSpinner" class="spinner-border spinner-border-sm d-none"></span>
        Frissites
    </button>
</div>

<div class="card mb-4 shadow-sm">
    <div class="card-body">
        <h5 class="mb-3">Idopontok generalasa intervallumbol</h5>

        <form id="generateForm">
            <div class="row g-3 mb-3">
                <div class="col-md-6">
                    <label class="form-label">Kezdo idopont</label>
                    <input type="datetime-local" name="start" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Zaro idopont</label>
                    <input type="datetime-local" name="end" class="form-control" required>
                </div>
            </div>

            <div class="text-muted mb-3">A generalas fixen 60 perces lepeskozzel tortenik.</div>
            <input type="hidden" name="step" value="60">

            <button class="btn btn-primary w-100" type="submit">
                <i class="bi bi-plus-circle"></i> Idopontok generalasa
            </button>
        </form>
    </div>
</div>

<div class="card mb-4 shadow-sm">
    <div class="card-body">
        <h5 class="mb-3">Szabalytalan idopontok torlese (H-P, 10-18)</h5>

        <form id="refreshForm">
            <button class="btn btn-warning w-100" type="submit">
                <i class="bi bi-exclamation-triangle"></i> Szabalytalan idopontok torlese
            </button>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="d-flex flex-wrap align-items-end gap-3 justify-content-between mb-3">
            <div>
                <h5 class="mb-1">Idopontok listaja</h5>
                <p class="text-muted mb-0">Havi szures mellett heti szakaszokban lapozhato lista.</p>
            </div>

            <div class="d-flex flex-wrap align-items-center gap-2">
                <button class="btn btn-outline-secondary" id="prevMonthBtn" type="button">
                    <i class="bi bi-chevron-left"></i>
                </button>
                <input type="month" id="timeslotsMonthPicker" class="form-control" value="<?= htmlspecialchars((string) $selectedMonth, ENT_QUOTES, 'UTF-8') ?>">
                <button class="btn btn-outline-secondary" id="nextMonthBtn" type="button">
                    <i class="bi bi-chevron-right"></i>
                </button>
            </div>
        </div>

        <div class="d-flex flex-wrap align-items-center gap-2 justify-content-between mb-3">
            <div class="d-flex align-items-center gap-2">
                <button class="btn btn-outline-secondary btn-sm" id="prevWeekBtn" type="button">
                    <i class="bi bi-chevron-left"></i>
                </button>
                <span class="text-muted" id="timeslotsWeekLabel"></span>
                <button class="btn btn-outline-secondary btn-sm" id="nextWeekBtn" type="button">
                    <i class="bi bi-chevron-right"></i>
                </button>
            </div>
            <span class="text-muted" id="timeslotsWeekCounter"></span>
        </div>

        <table class="table table-hover" id="timeslotsTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Idopont</th>
                    <th>Statusz</th>
                    <th class="text-end">Muveletek</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
        <div class="text-muted d-none" id="timeslotsEmptyState">Nincs idopont a kivalasztott honapban.</div>
    </div>
</div>

<div class="modal fade" id="timeslotModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content" id="timeslotModalContent"></div>
    </div>
</div>
