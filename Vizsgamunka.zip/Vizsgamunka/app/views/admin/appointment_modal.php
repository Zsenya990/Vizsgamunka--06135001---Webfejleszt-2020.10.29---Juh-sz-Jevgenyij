<?php if (empty($appointment)): ?>
    <div class="p-4">
        <div class="alert alert-danger mb-0">A keresett foglalas nem talalhato.</div>
    </div>
<?php else: ?>
    <div class="modal-header">
        <h5 class="modal-title">Foglalas #<?= (int) $appointment['id'] ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>
    <div class="modal-body">
        <p><strong>Nev:</strong> <?= htmlspecialchars((string) $appointment['name'], ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars((string) $appointment['email'], ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>Telefon:</strong> <?= htmlspecialchars((string) $appointment['phone'], ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>Uzenet:</strong><br><?= nl2br(htmlspecialchars((string) ($appointment['message'] ?? ''), ENT_QUOTES, 'UTF-8')) ?></p>
        <p><strong>Idopont:</strong> <?= htmlspecialchars((string) ($appointment['timeslot'] ?? ''), ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>Allapot:</strong> <?= htmlspecialchars((string) ($appointment['allapot'] ?? ''), ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>Letrehozva:</strong> <?= htmlspecialchars((string) ($appointment['created_at'] ?? ''), ENT_QUOTES, 'UTF-8') ?></p>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Bezaras</button>
    </div>
<?php endif; ?>
