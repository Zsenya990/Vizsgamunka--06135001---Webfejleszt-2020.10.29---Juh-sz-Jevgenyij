<?php
$pageTitle = $title ?? 'Admin Panel';
$currentRoute = trim((string) ($_GET['route'] ?? 'admin'), '/');
$pageScripts = $pageScripts ?? [];
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= htmlspecialchars(asset_url('public/assets/admin/css/admin.css'), ENT_QUOTES, 'UTF-8') ?>">
</head>
<body class="admin-shell" data-app-section="admin">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="<?= htmlspecialchars(app_url('admin'), ENT_QUOTES, 'UTF-8') ?>">Admin Panel</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="adminNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link <?= $currentRoute === 'admin' ? 'active' : '' ?>" href="<?= htmlspecialchars(app_url('admin'), ENT_QUOTES, 'UTF-8') ?>">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link <?= $currentRoute === 'admin/appointments' ? 'active' : '' ?>" href="<?= htmlspecialchars(app_url('admin/appointments'), ENT_QUOTES, 'UTF-8') ?>">Foglalasok</a></li>
                <li class="nav-item"><a class="nav-link <?= $currentRoute === 'admin/timeslots' ? 'active' : '' ?>" href="<?= htmlspecialchars(app_url('admin/timeslots'), ENT_QUOTES, 'UTF-8') ?>">Idopontok</a></li>
                <li class="nav-item"><a class="nav-link <?= $currentRoute === 'admin/summary' ? 'active' : '' ?>" href="<?= htmlspecialchars(app_url('admin/summary'), ENT_QUOTES, 'UTF-8') ?>">Osszegzes</a></li>
                <li class="nav-item"><a class="nav-link <?= $currentRoute === 'admin/logs' ? 'active' : '' ?>" href="<?= htmlspecialchars(app_url('admin/logs'), ENT_QUOTES, 'UTF-8') ?>">Logok</a></li>
                <li class="nav-item">
                    <form method="post" action="<?= htmlspecialchars(app_url('admin/logout'), ENT_QUOTES, 'UTF-8') ?>" class="d-inline">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string) ($_SESSION['admin_csrf_token'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
                        <button type="submit" class="nav-link text-danger border-0 bg-transparent">Kijelentkezes</button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav>

<main class="container admin-content">
    <?= $content ?>
</main>

<footer class="text-center mt-5 mb-3">
    <p class="text-muted mb-0">&copy; <?= date('Y') ?> Admin felulet</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
window.APP_CONFIG = {
    baseUrl: <?= json_encode(APP_BASE_PATH, JSON_UNESCAPED_UNICODE) ?>,
    csrfToken: <?= json_encode((string) ($_SESSION['admin_csrf_token'] ?? ''), JSON_UNESCAPED_UNICODE) ?>
};
</script>
<script src="<?= htmlspecialchars(asset_url('public/assets/admin/js/http.js'), ENT_QUOTES, 'UTF-8') ?>"></script>
<?php foreach ($pageScripts as $script): ?>
    <script src="<?= htmlspecialchars($script, ENT_QUOTES, 'UTF-8') ?>"></script>
<?php endforeach; ?>
</body>
</html>
