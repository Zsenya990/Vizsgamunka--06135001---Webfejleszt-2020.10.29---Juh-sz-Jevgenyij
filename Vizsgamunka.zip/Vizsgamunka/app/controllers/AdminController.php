<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Models\Appointment;
use App\Models\LogEntry;
use App\Models\Timeslot;

class AdminController extends BaseController
{
    private Appointment $appointment;
    private LogEntry $logEntry;
    private Timeslot $timeslot;

    private array $allowedStatuses = ['uj', 'elfogadva', 'teljesult', 'torolve'];

    public function __construct()
    {
        $this->appointment = new Appointment();
        $this->logEntry = new LogEntry();
        $this->timeslot = new Timeslot();
    }

    public function dashboard(): void
    {
        $this->requireAdmin();

        $defaultMonth = date('Y-m');
        $defaultYear = date('Y');

        $this->render('admin/dashboard', [
            'title' => 'Admin Dashboard',
            'freeMonth' => (string) ($_GET['free_month'] ?? $defaultMonth),
            'weeklyMonth' => (string) ($_GET['weekly_month'] ?? $defaultMonth),
            'monthlyYear' => (string) ($_GET['monthly_year'] ?? $defaultYear),
            'pageScripts' => [
                asset_url('public/assets/admin/js/dashboard.js'),
            ],
        ], 'admin');
    }

    public function appointments(): void
    {
        $this->requireAdmin();

        $this->render('admin/appointments', [
            'title' => 'Foglalasok',
            'pageScripts' => [
                asset_url('public/assets/admin/js/appointments.js'),
            ],
        ], 'admin');
    }

    public function timeslots(): void
    {
        $this->requireAdmin();

        $this->render('admin/timeslots', [
            'title' => 'Idopontok',
            'selectedMonth' => (string) ($_GET['month'] ?? date('Y-m')),
            'pageScripts' => [
                asset_url('public/assets/admin/js/timeslots.js'),
            ],
        ], 'admin');
    }

    public function summary(): void
    {
        $this->requireAdmin();

        $this->render('admin/summary', [
            'title' => 'Osszegzes',
            'dailyMonth' => (string) ($_GET['daily_month'] ?? date('Y-m')),
            'pageScripts' => [
                asset_url('public/assets/admin/js/summary.js'),
            ],
        ], 'admin');
    }

    public function logs(): void
    {
        $this->requireAdmin();

        $filters = [
            'category' => (string) ($_GET['category'] ?? ''),
            'level' => (string) ($_GET['level'] ?? ''),
            'date' => (string) ($_GET['date'] ?? ''),
        ];

        $this->render('admin/logs', [
            'title' => 'Logok',
            'filters' => $filters,
            'entries' => $this->logEntry->list($filters),
            'categories' => $this->logEntry->categories(),
            'levels' => $this->logEntry->levels(),
            'stats' => $this->logEntry->stats(),
        ], 'admin');
    }

    public function viewAppointment(string|int $id): void
    {
        $this->requireAdmin();
        $appointment = $this->appointment->getById((int) $id);
        if (!$appointment) {
            $this->abort(404, 'A foglalas nem talalhato.');
        }

        $this->renderPartial('admin/appointment_modal', [
            'appointment' => $appointment,
        ]);
    }

    public function statusModal(string|int $id): void
    {
        $this->requireAdmin();
        $appointment = $this->appointment->getById((int) $id);
        if (!$appointment) {
            $this->abort(404, 'A foglalas nem talalhato.');
        }

        $this->renderPartial('admin/status_modal', [
            'appointment' => $appointment,
            'allowedStatuses' => $this->allowedStatuses,
        ]);
    }

    public function editAppointment(string|int $id): void
    {
        $this->requireAdmin();

        $appointment = $this->appointment->getById((int) $id);
        if (!$appointment) {
            $this->abort(404, 'A foglalas nem talalhato.');
        }

        $timeslotId = (int) ($appointment['timeslot_id'] ?? 0);

        $this->renderPartial('admin/appointment_edit_modal', [
            'appointment' => $appointment,
            'timeslots' => $timeslotId > 0 ? $this->timeslot->getRescheduleOptions($timeslotId) : [],
        ]);
    }

    public function editTimeslot(string|int $id): void
    {
        $this->requireAdmin();
        $timeslot = $this->timeslot->getById((int) $id);
        if (!$timeslot) {
            $this->abort(404, 'Az idopont nem talalhato.');
        }

        $this->renderPartial('admin/timeslot_modal', [
            'timeslot' => $timeslot,
        ]);
    }

    public function exportAppointments(): void
    {
        $this->requireAdmin();

        $status = (string) ($_GET['status'] ?? '');
        $month = (string) ($_GET['month'] ?? '');
        $rows = $this->appointment->getExportData($status, $month);

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="appointments_export_' . date('Y-m-d') . '.csv"');

        echo "\xEF\xBB\xBF";
        echo implode(';', ['ID', 'Nev', 'Email', 'Telefon', 'Uzenet', 'Allapot', 'Idopont', 'Letrehozva']) . "\n";

        foreach ($rows as $row) {
            if (isset($row[3])) {
                $row[3] = '="' . str_replace('"', '""', (string) $row[3]) . '"';
            }

            $escaped = array_map(static function ($value): string {
                $value = str_replace('"', '""', (string) $value);
                return '"' . $value . '"';
            }, $row);

            echo implode(';', $escaped) . "\n";
        }
    }

    public function exportLogs(): void
    {
        $this->requireAdmin();

        $filters = [
            'category' => (string) ($_GET['category'] ?? ''),
            'level' => (string) ($_GET['level'] ?? ''),
            'date' => (string) ($_GET['date'] ?? ''),
        ];
        $rows = $this->logEntry->list($filters, 5000);

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="logs_export_' . date('Y-m-d_H-i-s') . '.csv"');

        echo "\xEF\xBB\xBF";
        echo implode(';', ['Idopont', 'Szint', 'Kategoria', 'Uzenet', 'IP', 'Method', 'URI', 'Context']) . "\n";

        foreach ($rows as $row) {
            $line = [
                (string) ($row['timestamp'] ?? ''),
                (string) ($row['level'] ?? ''),
                (string) ($row['category'] ?? ''),
                (string) ($row['message'] ?? ''),
                (string) ($row['ip'] ?? ''),
                (string) ($row['method'] ?? ''),
                (string) ($row['request_uri'] ?? ''),
                json_encode($row['context'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ];

            $escaped = array_map(static function ($value): string {
                $value = str_replace('"', '""', (string) $value);
                return '"' . $value . '"';
            }, $line);

            echo implode(';', $escaped) . "\n";
        }
    }

}
