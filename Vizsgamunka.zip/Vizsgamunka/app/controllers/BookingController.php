<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\HumanCheck;

class BookingController extends BaseController
{
    public function index(): void
    {
        if (!isset($_SESSION['form_token'])) {
            $_SESSION['form_token'] = bin2hex(random_bytes(16));
        }

        $this->render('booking/index', [
            'title' => 'Foglalas',
            'token' => $_SESSION['form_token'],
            'humanCheckQuestion' => HumanCheck::currentQuestion(),
            'pageScripts' => [
                asset_url('public/assets/js/calendar.js'),
                asset_url('public/assets/js/booking.js'),
            ],
        ]);
    }
}
