# Vizsgamunka

## Projektstruktura

- `app/controllers/`
  - szerveroldali MVC kontrollerek
  - `Api/`
    - `AdminApiController.php`: admin REST API
    - `PublicApiController.php`: publikus REST API
- `app/models/`
  - adatbazis-modellek
- `app/views/`
  - nezettek es layoutok

- `public/index.php`
  - front controller
- `public/core/router.php`
  - router
- `public/routes/`
  - `web.php`: publikus HTML route-ok
  - `admin.php`: admin HTML route-ok
  - `api.php`: API route gyujto
  - `api_public.php`: publikus API route-ok
  - `api_admin.php`: admin API route-ok

- `public/assets/css/`
  - publikus CSS
- `public/assets/js/`
  - publikus JS
- `public/assets/admin/css/`
  - admin CSS
- `public/assets/admin/js/`
  - admin JS

## API szetvalasztas

- Publikus API:
  - foglalas inditas
  - foglalas letrehozas
  - elerheto honapok, napok, idopontok
- Admin API:
  - foglalas CRUD es statuszkezeles
  - idopont CRUD es generalas
  - dashboard es osszegzes adatok

## Belepesi pontok

- publikus oldal: `/`
- foglalas: `/foglalas`
- admin: `/admin`
- REST API: `/api/...`
