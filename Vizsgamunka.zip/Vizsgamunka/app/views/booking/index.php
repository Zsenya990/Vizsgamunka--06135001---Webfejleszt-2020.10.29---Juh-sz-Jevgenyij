<div class="row g-4">
    <div class="col-lg-7">
        <div class="card shadow p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <button id="prevMonth" class="btn btn-outline-primary" type="button">&larr;</button>
                <h2 id="monthLabel" class="calendar-header mb-0"></h2>
                <button id="nextMonth" class="btn btn-outline-primary" type="button">&rarr;</button>
            </div>
            <div id="calendarGrid" class="calendar-grid"></div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card shadow p-4 h-100">
            <h3 class="mb-3">Szabad idopontok</h3>
            <div id="timeslotContainer"></div>
            <p id="timeslotEmptyState" class="text-muted mt-3 mb-0">Valassz egy napot az elerheto idopontok megjelenitesehez.</p>

            <hr class="my-4">

            <form id="bookingForm" style="display:none;">
                <input type="hidden" name="token" value="<?= htmlspecialchars($token ?? '', ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="timeslot_id" id="selectedTimeslot">
                <input type="text" name="website" class="d-none" tabindex="-1" autocomplete="off">

                <div id="bookingTimerPanel" class="booking-timer-panel d-none" aria-live="polite">
                    <div id="bookingTimerClock" class="booking-timer-clock" style="--timer-progress: 1;">
                        <span class="booking-timer-clock-icon">&#128339;</span>
                    </div>
                    <div class="booking-timer-copy">
                        <div class="booking-timer-label">Foglalasi idokeret</div>
                        <div id="bookingTimerText" class="booking-timer-text">05:00</div>
                        <div id="bookingTimerHint" class="booking-timer-hint">
                            5 perced van a foglalas befejezesere.
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label" for="bookingName">Nev</label>
                    <input id="bookingName" type="text" name="name" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label" for="bookingEmail">E-mail</label>
                    <input id="bookingEmail" type="email" name="email" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label" for="bookingPhone">Telefonszam</label>
                    <input id="bookingPhone" type="text" name="phone" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label" for="bookingMessage">Uzenet</label>
                    <textarea id="bookingMessage" name="message" class="form-control" rows="4"></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label" for="humanAnswer">
                        Biztonsagi ellenorzes: <span id="humanCheckQuestion"><?= htmlspecialchars((string) ($humanCheckQuestion ?? ''), ENT_QUOTES, 'UTF-8') ?></span>
                    </label>
                    <input id="humanAnswer" type="text" name="human_answer" class="form-control" inputmode="numeric" autocomplete="off" required>
                </div>

                <div id="bookingErrors" class="alert alert-danger d-none"></div>

                <button type="submit" class="btn btn-primary w-100">Foglalas kuldese</button>
            </form>
        </div>
    </div>
</div>
