<?php

declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOException;
use RuntimeException;

final class Database
{
    private static ?PDO $connection = null;
    private static bool $schemaChecked = false;

    public static function getConnection(): PDO
    {
        if (self::$connection instanceof PDO) {
            return self::$connection;
        }

        $env = Config::env();

        try {
            self::$connection = new PDO(
                sprintf(
                    'mysql:host=%s;dbname=%s;charset=utf8mb4',
                    $env['DB_HOST'] ?? 'localhost',
                    $env['DB_NAME'] ?? ''
                ),
                $env['DB_USER'] ?? '',
                $env['DB_PASS'] ?? '',
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $exception) {
            throw new RuntimeException('Database connection failed.', 0, $exception);
        }

        self::ensureSchema(self::$connection, (string) ($env['DB_NAME'] ?? ''));

        return self::$connection;
    }

    private static function ensureSchema(PDO $pdo, string $databaseName): void
    {
        if (self::$schemaChecked || $databaseName === '') {
            return;
        }

        self::$schemaChecked = true;

        $messageColumn = $pdo->prepare(
            "SELECT COUNT(*)
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = ?
               AND TABLE_NAME = 'appointments'
               AND COLUMN_NAME = 'message'"
        );
        $messageColumn->execute([$databaseName]);

        if ((int) $messageColumn->fetchColumn() === 0) {
            $pdo->exec("ALTER TABLE appointments ADD COLUMN message TEXT NULL AFTER phone");
        }

        $statusColumn = $pdo->prepare(
            "SELECT COLUMN_TYPE
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = ?
               AND TABLE_NAME = 'appointments'
               AND COLUMN_NAME = 'allapot'"
        );
        $statusColumn->execute([$databaseName]);
        $columnType = (string) $statusColumn->fetchColumn();

        if ($columnType !== '' && !str_contains($columnType, "'teljesult'")) {
            $pdo->exec("ALTER TABLE appointments MODIFY allapot ENUM('uj','elfogadva','teljesult','torolve','') NOT NULL DEFAULT 'uj'");
        }
    }
}
