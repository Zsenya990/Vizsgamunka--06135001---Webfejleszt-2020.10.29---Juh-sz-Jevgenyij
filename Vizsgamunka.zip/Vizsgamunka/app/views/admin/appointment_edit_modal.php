<?php if (empty($appointment)): ?>
    <div class="p-4">
        <div class="alert alert-danger mb-0">A keresett foglalas nem talalhato.</div>
    </div>
<?php else: ?>
    <div class="modal-header">
        <h5 class="modal-title">Foglalas idopontjanak modositasa (#<?= (int) $appointment['id'] ?>)</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>

    <div class="modal-body">
        <form id="updateAppointmentTimeslotForm">
            <input type="hidden" name="appointment_id" value="<?= (int) $appointment['id'] ?>">

            <div class="mb-3">
                <label class="form-label">Jelenlegi idopont</label>
                <input
                    type="text"
                    class="form-control"
                    value="<?= htmlspecialchars((string) ($appointment['timeslot'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"
                    disabled
                >
            </div>

            <div class="mb-3">
                <label class="form-label" for="appointmentTimeslotSelect">Uj idopont</label>
                <select id="appointmentTimeslotSelect" name="timeslot_id" class="form-select" required<?= empty($timeslots) ? ' disabled' : '' ?>>
                    <?php if (empty($timeslots)): ?>
                        <option value="">Nincs elerheto idopont</option>
                    <?php else: ?>
                        <?php foreach ($timeslots as $timeslot): ?>
                            <?php
                            $isCurrent = (int) $timeslot['id'] === (int) $appointment['timeslot_id'];
                            $label = date('Y-m-d H:i', strtotime((string) $timeslot['timeslot']));
                            if ($isCurrent) {
                                $label .= ' (jelenlegi)';
                            }
                            ?>
                            <option value="<?= (int) $timeslot['id'] ?>"<?= $isCurrent ? ' selected' : '' ?>>
                                <?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="alert alert-info mb-0">
                Mentes utan a foglalo e-mailben ertesitest kap az uj idopontrol.
            </div>
        </form>
    </div>

    <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="saveAppointmentTimeslotBtn"<?= empty($timeslots) ? ' disabled' : '' ?>>Mentes</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Megse</button>
    </div>
<?php endif; ?>
