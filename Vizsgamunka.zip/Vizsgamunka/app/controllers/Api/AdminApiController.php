<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Core\Logger;
use App\Core\Mailer;
use App\Models\Appointment;
use App\Models\Timeslot;

class AdminApiController extends BaseController
{
    private Appointment $appointment;
    private Timeslot $timeslot;

    private array $allowedStatuses = ['uj', 'elfogadva', 'teljesult', 'torolve'];

    public function __construct()
    {
        $this->appointment = new Appointment();
        $this->timeslot = new Timeslot();
    }

    public function listAppointments(): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $status = trim((string) ($_GET['status'] ?? ''));
        $month = trim((string) ($_GET['month'] ?? ''));

        if ($status !== '' && !in_array($status, $this->allowedStatuses, true)) {
            $this->json(['error' => 'invalid_status'], 422);
            return;
        }

        if ($month !== '' && !$this->isValidMonth($month)) {
            $this->json(['error' => 'invalid_month'], 422);
            return;
        }

        $this->json($this->appointment->getFiltered($status, $month));
    }

    public function getAppointment(string|int $id): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $appointment = $this->appointment->getById((int) $id);
        if (!$appointment) {
            $this->json(['error' => 'not_found'], 404);
            return;
        }

        $this->json($appointment);
    }

    public function updateAppointment(string|int $id): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $appointmentId = (int) $id;
        $appointment = $this->appointment->getById($appointmentId);
        if (!$appointment) {
            $this->json(['error' => 'not_found'], 404);
            return;
        }

        $data = $this->requestData();
        $response = ['success' => true];

        if (isset($data['status'])) {
            $status = trim((string) $data['status']);
            if (!in_array($status, $this->allowedStatuses, true)) {
                $this->json(['error' => 'invalid_status'], 422);
                return;
            }

            $this->appointment->updateStatus($appointmentId, $status);
            $response['status'] = $status;
            Logger::info('admin', 'Appointment status updated', [
                'appointment_id' => $appointmentId,
                'status' => $status,
                'admin' => $_SESSION['admin_username'] ?? '',
            ]);
        }

        if (isset($data['timeslot_id'])) {
            $timeslotId = (int) $data['timeslot_id'];
            if ($timeslotId <= 0) {
                $this->json(['error' => 'invalid_timeslot_id'], 422);
                return;
            }

            $result = $this->appointment->reschedule($appointmentId, $timeslotId);
            if (!($result['success'] ?? false)) {
                $this->json($result, 409);
                return;
            }

            $updatedAppointment = $result['appointment'] ?? [];
            if ((bool) ($result['changed'] ?? true)) {
                Logger::info('admin', 'Appointment rescheduled', [
                    'appointment_id' => $appointmentId,
                    'old_timeslot' => $result['old_timeslot'] ?? '',
                    'new_timeslot' => $result['new_timeslot'] ?? '',
                    'admin' => $_SESSION['admin_username'] ?? '',
                ]);
                $response['mailSent'] = Mailer::sendAppointmentRescheduled(
                    (string) ($updatedAppointment['email'] ?? ''),
                    (string) ($updatedAppointment['name'] ?? ''),
                    (string) ($result['old_timeslot'] ?? ''),
                    (string) ($result['new_timeslot'] ?? '')
                );
            }

            $response['changed'] = (bool) ($result['changed'] ?? true);
        }

        $response['data'] = $this->appointment->getById($appointmentId);
        $this->json($response);
    }

    public function deleteAppointment(string|int $id): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $deleted = $this->appointment->delete((int) $id);
        if (!$deleted) {
            $this->json(['error' => 'not_found'], 404);
            return;
        }

        Logger::warning('admin', 'Appointment deleted', [
            'appointment_id' => (int) $id,
            'admin' => $_SESSION['admin_username'] ?? '',
        ]);
        $this->json(['success' => true]);
    }

    public function listTimeslots(): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $month = trim((string) ($_GET['month'] ?? ''));
        if ($month !== '' && !$this->isValidMonth($month)) {
            $this->json(['error' => 'invalid_month'], 422);
            return;
        }

        $this->json($this->timeslot->getAllFiltered($month));
    }

    public function getTimeslot(string|int $id): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $timeslot = $this->timeslot->getById((int) $id);
        if (!$timeslot) {
            $this->json(['error' => 'not_found'], 404);
            return;
        }

        $this->json($timeslot);
    }

    public function createTimeslot(): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $data = $this->requestData();
        $timeslot = trim((string) ($data['timeslot'] ?? ''));
        $isBooked = !empty($data['is_booked']);

        if ($timeslot === '') {
            $this->json(['error' => 'invalid_payload'], 422);
            return;
        }

        try {
            $normalizedTimeslot = $this->normalizeDatetime($timeslot);
        } catch (\InvalidArgumentException) {
            $this->json(['error' => 'invalid_timeslot'], 422);
            return;
        }

        $timeslotId = $this->timeslot->create($normalizedTimeslot, $isBooked ? 1 : 0);
        if ($timeslotId === false) {
            $this->json(['error' => 'create_failed'], 500);
            return;
        }

        Logger::info('admin', 'Timeslot created', [
            'timeslot_id' => $timeslotId,
            'timeslot' => $normalizedTimeslot,
            'admin' => $_SESSION['admin_username'] ?? '',
        ]);
        $this->json(['success' => true, 'data' => $this->timeslot->getById($timeslotId)], 201);
    }

    public function updateTimeslot(string|int $id): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $timeslotId = (int) $id;
        $current = $this->timeslot->getById($timeslotId);
        if (!$current) {
            $this->json(['error' => 'not_found'], 404);
            return;
        }

        $data = $this->requestData();
        if (isset($data['timeslot']) && trim((string) $data['timeslot']) !== '') {
            try {
                $normalizedTimeslot = $this->normalizeDatetime((string) $data['timeslot']);
            } catch (\InvalidArgumentException) {
                $this->json(['error' => 'invalid_timeslot'], 422);
                return;
            }

            $updated = $this->timeslot->update($timeslotId, $normalizedTimeslot);
            if (!$updated) {
                $this->json(['error' => 'timeslot_conflict'], 409);
                return;
            }

            Logger::info('admin', 'Timeslot updated', [
                'timeslot_id' => $timeslotId,
                'timeslot' => $normalizedTimeslot,
                'admin' => $_SESSION['admin_username'] ?? '',
            ]);
        }

        if (isset($data['is_booked'])) {
            $this->timeslot->setBookedStatus($timeslotId, (bool) $data['is_booked']);
            Logger::info('admin', 'Timeslot booking flag updated', [
                'timeslot_id' => $timeslotId,
                'is_booked' => (bool) $data['is_booked'],
                'admin' => $_SESSION['admin_username'] ?? '',
            ]);
        }

        $this->json(['success' => true, 'data' => $this->timeslot->getById($timeslotId)]);
    }

    public function deleteTimeslot(string|int $id): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $deleted = $this->timeslot->delete((int) $id);
        if (!$deleted) {
            $this->json(['error' => 'timeslot_in_use'], 409);
            return;
        }

        Logger::warning('admin', 'Timeslot deleted', [
            'timeslot_id' => (int) $id,
            'admin' => $_SESSION['admin_username'] ?? '',
        ]);
        $this->json(['success' => true]);
    }

    public function generateTimeslots(): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $data = $this->requestData();
        $start = trim((string) ($data['start'] ?? ''));
        $end = trim((string) ($data['end'] ?? ''));
        $step = 60;

        if ($start === '' || $end === '' || $step <= 0) {
            $this->json(['error' => 'invalid_payload'], 422);
            return;
        }

        try {
            $normalizedStart = $this->normalizeDatetime($start);
            $normalizedEnd = $this->normalizeDatetime($end);
        } catch (\InvalidArgumentException) {
            $this->json(['error' => 'invalid_timeslot_range'], 422);
            return;
        }

        if ($normalizedStart > $normalizedEnd) {
            $this->json(['error' => 'invalid_timeslot_range'], 422);
            return;
        }

        $this->timeslot->generate($normalizedStart, $normalizedEnd, $step);
        Logger::info('admin', 'Timeslots generated', [
            'start' => $normalizedStart,
            'end' => $normalizedEnd,
            'step' => $step,
            'admin' => $_SESSION['admin_username'] ?? '',
        ]);
        $this->json(['success' => true]);
    }

    public function refreshTimeslots(): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $this->timeslot->refreshInvalid();
        Logger::info('admin', 'Invalid timeslots refreshed', [
            'admin' => $_SESSION['admin_username'] ?? '',
        ]);
        $this->json(['success' => true]);
    }

    public function dashboardSummary(): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $dailyMonth = trim((string) ($_GET['daily_month'] ?? ''));
        if ($dailyMonth !== '' && !$this->isValidMonth($dailyMonth)) {
            $this->json(['error' => 'invalid_month'], 422);
            return;
        }

        $this->json(
            $this->appointment->getSummaryData(
                $this->allowedStatuses,
                $this->timeslot->getSlotCounts(),
                $dailyMonth !== '' ? $dailyMonth : null
            )
        );
    }

    public function dashboardCharts(): void
    {
        if (!$this->requireAdminApi()) {
            return;
        }

        $freeMonth = trim((string) ($_GET['free_month'] ?? date('Y-m')));
        $weeklyMonth = trim((string) ($_GET['weekly_month'] ?? date('Y-m')));
        $monthlyYear = trim((string) ($_GET['monthly_year'] ?? date('Y')));

        if (
            !$this->isValidMonth($freeMonth) ||
            !$this->isValidMonth($weeklyMonth) ||
            !$this->isValidYear($monthlyYear)
        ) {
            $this->json(['error' => 'invalid_filters'], 422);
            return;
        }

        $this->json(
            $this->appointment->getChartData(
                $freeMonth,
                $weeklyMonth,
                $monthlyYear,
                $this->timeslot->getMonthCounts($freeMonth)
            )
        );
    }

    private function normalizeDatetime(string $value): string
    {
        $normalized = trim(str_replace('T', ' ', $value));
        $formats = ['Y-m-d H:i:s', 'Y-m-d H:i'];

        foreach ($formats as $format) {
            $date = \DateTimeImmutable::createFromFormat($format, $normalized);
            $errors = \DateTimeImmutable::getLastErrors();
            $warningCount = is_array($errors) ? ($errors['warning_count'] ?? 0) : 0;
            $errorCount = is_array($errors) ? ($errors['error_count'] ?? 0) : 0;

            if ($date instanceof \DateTimeImmutable && $warningCount === 0 && $errorCount === 0) {
                return $date->format('Y-m-d H:i:s');
            }
        }

        throw new \InvalidArgumentException('Invalid datetime value.');
    }

    private function isValidMonth(string $value): bool
    {
        return preg_match('/^\d{4}-\d{2}$/', $value) === 1;
    }

    private function isValidYear(string $value): bool
    {
        return preg_match('/^\d{4}$/', $value) === 1;
    }
}
