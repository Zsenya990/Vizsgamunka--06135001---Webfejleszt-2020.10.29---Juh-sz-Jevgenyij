<?php

declare(strict_types=1);

namespace App\Core;

final class Validator
{
    public static function required(string $value): bool
    {
        return trim($value) !== '';
    }

    public static function email(string $value): bool
    {
        return filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
    }

    public static function maxLength(string $value, int $length): bool
    {
        return mb_strlen($value) <= $length;
    }

    public static function phone(string $value): bool
    {
        return preg_match('/^[0-9+()\\-\\s]{7,20}$/', $value) === 1;
    }

    public static function int(mixed $value): bool
    {
        return filter_var($value, FILTER_VALIDATE_INT) !== false;
    }
}