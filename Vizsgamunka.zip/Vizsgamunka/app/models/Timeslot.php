<?php

declare(strict_types=1);

namespace App\Models;

class Timeslot extends BaseModel
{
    public function getAllFiltered(string $month = ''): array
    {
        if ($month !== '') {
            return $this->getByMonth($month);
        }

        return $this->fetchAll("SELECT * FROM timeslots ORDER BY timeslot ASC");
    }

    public function getByMonth(string $month): array
    {
        return $this->fetchAll(
            "SELECT *
             FROM timeslots
             WHERE DATE_FORMAT(timeslot, '%Y-%m') = ?
             ORDER BY timeslot ASC",
            [$month]
        );
    }

    public function getById(int $id): array|false
    {
        return $this->fetch("SELECT * FROM timeslots WHERE id = ?", [$id]);
    }

    public function getRescheduleOptions(int $currentTimeslotId): array
    {
        return $this->fetchAll(
            "SELECT id, timeslot, is_booked
             FROM timeslots
             WHERE timeslot >= NOW()
               AND (is_booked = 0 OR id = ?)
             ORDER BY timeslot ASC",
            [$currentTimeslotId]
        );
    }

    public function update(int $id, string $timeslot): bool
    {
        $stmt = $this->run(
            "UPDATE timeslots
             SET timeslot = ?
             WHERE id = ?
               AND NOT EXISTS (
                   SELECT 1
                   FROM timeslots duplicate_slot
                   WHERE duplicate_slot.timeslot = ?
                     AND duplicate_slot.id <> ?
               )",
            [$timeslot, $id, $timeslot, $id]
        );

        return $stmt->rowCount() === 1;
    }

    public function create(string $timeslot, int $isBooked = 0): int|false
    {
        $this->executeQuery(
            "INSERT INTO timeslots (timeslot, is_booked)
             SELECT ?, ?
             WHERE NOT EXISTS (SELECT 1 FROM timeslots WHERE timeslot = ?)",
            [$timeslot, $isBooked, $timeslot]
        );

        $createdId = (int) $this->pdo->lastInsertId();
        if ($createdId > 0) {
            return $createdId;
        }

        $existingId = $this->fetchColumn("SELECT id FROM timeslots WHERE timeslot = ?", [$timeslot]);
        return $existingId !== false ? (int) $existingId : false;
    }

    public function setBookedStatus(int $id, bool $booked): bool
    {
        return $this->executeQuery("UPDATE timeslots SET is_booked = ? WHERE id = ?", [$booked ? 1 : 0, $id]);
    }

    public function delete(int $id): bool
    {
        $hasAppointment = (int) $this->fetchColumn("SELECT COUNT(*) FROM appointments WHERE timeslot_id = ?", [$id]) > 0;
        if ($hasAppointment) {
            return false;
        }

        $stmt = $this->run(
            "DELETE FROM timeslots
             WHERE id = ?
               AND is_booked = 0",
            [$id]
        );

        return $stmt->rowCount() === 1;
    }

    public function generate(string $start, string $end, int $step): void
    {
        $current = strtotime($start);
        $endTime = strtotime($end);

        while ($current <= $endTime) {
            $slot = date('Y-m-d H:i:s', $current);
            $this->executeQuery(
                "INSERT INTO timeslots (timeslot, is_booked)
                 SELECT ?, 0
                 WHERE NOT EXISTS (SELECT 1 FROM timeslots WHERE timeslot = ?)",
                [$slot, $slot]
            );

            $current = strtotime("+{$step} minutes", $current);
        }
    }

    public function refreshInvalid(): bool
    {
        return $this->executeQuery(
            "DELETE FROM timeslots
             WHERE is_booked = 0
               AND (
                    WEEKDAY(timeslot) > 4
                    OR HOUR(timeslot) < 10
                    OR HOUR(timeslot) >= 18
               )"
        );
    }

    public function isFree(int $id): bool
    {
        return (int) $this->fetchColumn("SELECT is_booked FROM timeslots WHERE id = ?", [$id]) === 0;
    }

    public function getAvailableMonths(): array
    {
        return $this->fetchAll(
            "SELECT DISTINCT DATE_FORMAT(timeslot, '%Y-%m') AS month
             FROM timeslots
             WHERE is_booked = 0
             ORDER BY month ASC",
            [],
            \PDO::FETCH_COLUMN
        );
    }

    public function getAvailableDaysByMonth(string $month): array
    {
        return $this->fetchAll(
            "SELECT DISTINCT DATE(timeslot) AS day
             FROM timeslots
             WHERE is_booked = 0
               AND DATE_FORMAT(timeslot, '%Y-%m') = ?
             ORDER BY day ASC",
            [$month],
            \PDO::FETCH_COLUMN
        );
    }

    public function getAvailableTimeslots(string $date): array
    {
        return $this->fetchAll(
            "SELECT id, timeslot, is_booked
             FROM timeslots
             WHERE DATE(timeslot) = ?
             ORDER BY timeslot ASC",
            [$date]
        );
    }

    public function getSlotCounts(): array
    {
        return [
            'free' => (int) $this->fetchColumn("SELECT COUNT(*) FROM timeslots WHERE is_booked = 0"),
            'booked' => (int) $this->fetchColumn("SELECT COUNT(*) FROM timeslots WHERE is_booked = 1"),
        ];
    }

    public function getMonthCounts(string $month): array
    {
        return [
            'total' => (int) $this->fetchColumn("SELECT COUNT(*) FROM timeslots WHERE DATE_FORMAT(timeslot, '%Y-%m') = ?", [$month]),
            'booked' => (int) $this->fetchColumn("SELECT COUNT(*) FROM timeslots WHERE is_booked = 1 AND DATE_FORMAT(timeslot, '%Y-%m') = ?", [$month]),
        ];
    }
}
