<?php

declare(strict_types=1);

namespace App\Models;

final class LogEntry
{
    public function list(array $filters = [], int $limit = 300): array
    {
        $entries = $this->readAll();

        $category = trim((string) ($filters['category'] ?? ''));
        $level = trim((string) ($filters['level'] ?? ''));
        $date = trim((string) ($filters['date'] ?? ''));

        $entries = array_filter($entries, static function (array $entry) use ($category, $level, $date): bool {
            if ($category !== '' && (string) ($entry['category'] ?? '') !== $category) {
                return false;
            }

            if ($level !== '' && (string) ($entry['level'] ?? '') !== $level) {
                return false;
            }

            if ($date !== '' && strncmp((string) ($entry['timestamp'] ?? ''), $date, 10) !== 0) {
                return false;
            }

            return true;
        });

        usort($entries, static fn(array $a, array $b): int => strcmp((string) ($b['timestamp'] ?? ''), (string) ($a['timestamp'] ?? '')));

        return array_slice($entries, 0, $limit);
    }

    public function categories(): array
    {
        $categories = array_map(
            static fn(array $entry): string => (string) ($entry['category'] ?? ''),
            $this->readAll()
        );
        $categories = array_values(array_unique(array_filter($categories)));
        sort($categories);

        return $categories;
    }

    public function levels(): array
    {
        $levels = array_map(
            static fn(array $entry): string => (string) ($entry['level'] ?? ''),
            $this->readAll()
        );
        $levels = array_values(array_unique(array_filter($levels)));
        sort($levels);

        return $levels;
    }

    public function stats(): array
    {
        $stats = [];

        foreach ($this->readAll() as $entry) {
            $category = (string) ($entry['category'] ?? 'general');
            if (!isset($stats[$category])) {
                $stats[$category] = 0;
            }
            $stats[$category]++;
        }

        ksort($stats);
        return $stats;
    }

    private function readAll(): array
    {
        $directory = dirname(__DIR__, 2) . '/storage/logs';
        if (!is_dir($directory)) {
            return [];
        }

        $files = glob($directory . '/app-*.log') ?: [];
        rsort($files);

        $entries = [];
        foreach ($files as $file) {
            $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if (!is_array($lines)) {
                continue;
            }

            foreach ($lines as $line) {
                $decoded = json_decode($line, true);
                if (is_array($decoded)) {
                    $entries[] = $decoded;
                }
            }
        }

        return $entries;
    }
}
