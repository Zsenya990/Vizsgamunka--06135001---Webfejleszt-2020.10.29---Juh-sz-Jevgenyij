<div class="card shadow p-5 text-center">
    <h1 class="mb-4">Udv a foglalasi rendszerben</h1>
    <p class="lead mb-4">
        Valassz idopontot online, majd kuldd be a foglalasod nehany adat megadasaval.
    </p>

    <button id="startBooking" class="cta-btn" type="button" style="font-size:22px; padding:16px 40px;">
        Foglalas megkezdese
    </button>

    <div id="loadingAnim" style="display:none; margin-top:25px;">
        <div class="spinner-border text-primary" role="status" style="width:3rem; height:3rem;"></div>
        <p class="mt-3">Betoltes...</p>
    </div>
</div>
