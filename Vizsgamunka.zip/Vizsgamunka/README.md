# Vizsgamunka

Egyszeru PHP MVC alapu idopontfoglalasi rendszer publikus foglalasi felulettel es kulon adminisztracios panellel.

## Funkciok

- publikus idopontfoglalas
- foglalasi idokeret es egyszeru botvedelem
- admin bejelentkezes es session vedelmek
- foglalasok kezelese, atmozgatasa, statuszfrissitese
- idopontok generalasa, szerkesztese, torlese
- dashboard, osszegzesek, logok es CSV export

## Technologiak

- PHP 8+
- MySQL / MariaDB
- JavaScript
- Bootstrap 5
- Apache rewrite szabalyok (`.htaccess`)

## Projektstruktura

- `app/controllers/`: MVC kontrollerek
- `app/controllers/Api/`: publikus es admin API kontrollerek
- `app/models/`: adatbazis-muveletek
- `app/views/`: nezetek es layoutok
- `app/core/`: konfiguracio, adatbazis, hibakezeles, naplozas
- `public/index.php`: front controller
- `public/core/router.php`: router
- `public/routes/`: route definiciok
- `public/assets/`: CSS es JavaScript allomanyok
- `schema.sql`: adatbazis schema

## Telepites

1. Hozz letre egy adatbazist, peldaul `vizsgamunka` neven.
2. Importald a `schema.sql` fajlt.
3. Masold a `.env.example` fajlt `.env` nevvel.
4. Add meg a sajat adatbazis-elereseidet a `.env` fajlban.
5. Hozz letre legalabb egy admin felhasznalot a `users` tablaban egy `password_hash()` altal generalt jelszo hash-sel.
6. Az Apache document root vagy alias mutasson a projektre, a rewrite szabalyokkal egyutt.

## Alap route-ok

- publikus oldal: `/`
- foglalas: `/foglalas`
- kapcsolat: `/kapcsolat`
- admin: `/admin`
- admin login: `/admin/login`
- REST API: `/api/...`

## API szetvalasztas

- publikus API:
  - foglalasi folyamat inditasa
  - foglalas letrehozasa
  - elerheto honapok, napok es idopontok lekerdezese
- admin API:
  - foglalasok listazasa, modositasa, torlese
  - idopontok CRUD es generalasa
  - dashboard es osszegzes adatok

## Biztonsagi elemek

- session alap admin authentikacio
- CSRF vedelem admin es kapcsolati formhoz
- session fingerprint ellenorzes adminnal
- login throttle
- biztonsagi headerek
- szerveroldali idopont-ellenorzes

## Fontos megjegyzes

- A `.env` es a `storage/logs/*.log` fajlok nem tartoznak a kiadhato verziohoz.
- Az uj foglalasok alapertelmezett statusza `uj`, az admin feluleten kezelhetok tovabb.
