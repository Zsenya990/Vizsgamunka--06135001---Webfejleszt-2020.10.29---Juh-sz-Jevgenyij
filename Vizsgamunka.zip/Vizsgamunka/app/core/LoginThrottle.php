<?php

declare(strict_types=1);

namespace App\Core;

final class LoginThrottle
{
    private const MAX_ATTEMPTS = 5;
    private const LOCKOUT_SECONDS = 300;

    public static function isLocked(string $key): bool
    {
        $state = self::read($key);
        return (int) ($state['locked_until'] ?? 0) > time();
    }

    public static function recordFailure(string $key): void
    {
        $state = self::read($key);
        $attempts = (int) ($state['attempts'] ?? 0) + 1;
        $lockedUntil = (int) ($state['locked_until'] ?? 0);

        if ($attempts >= self::MAX_ATTEMPTS) {
            $attempts = 0;
            $lockedUntil = time() + self::LOCKOUT_SECONDS;
        }

        self::write($key, [
            'attempts' => $attempts,
            'locked_until' => $lockedUntil,
        ]);
    }

    public static function clear(string $key): void
    {
        $file = self::file($key);
        if (is_file($file)) {
            @unlink($file);
        }
    }

    private static function read(string $key): array
    {
        $file = self::file($key);
        if (!is_file($file)) {
            return ['attempts' => 0, 'locked_until' => 0];
        }

        $json = file_get_contents($file);
        if (!is_string($json) || $json === '') {
            return ['attempts' => 0, 'locked_until' => 0];
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            return ['attempts' => 0, 'locked_until' => 0];
        }

        return $decoded;
    }

    private static function write(string $key, array $state): void
    {
        file_put_contents(self::file($key), json_encode($state, JSON_UNESCAPED_UNICODE), LOCK_EX);
    }

    private static function file(string $key): string
    {
        return rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
            . DIRECTORY_SEPARATOR
            . 'vizsgamunka_admin_login_'
            . sha1($key)
            . '.json';
    }
}
