<?php

use App\Controllers\Api\PublicApiController;

$router->post('api/booking-selection', [PublicApiController::class, 'startBookingSelection']);
$router->delete('api/booking-selection', [PublicApiController::class, 'clearBookingSelection']);
$router->post('api/appointments', [PublicApiController::class, 'createAppointment']);

$router->get('api/availability/months', [PublicApiController::class, 'availabilityMonths']);
$router->get('api/availability/days', [PublicApiController::class, 'availabilityDays']);
$router->get('api/availability/timeslots', [PublicApiController::class, 'availabilityTimeslots']);
$router->get('api/availability/timeslot/{id}', [PublicApiController::class, 'availabilityTimeslot']);
