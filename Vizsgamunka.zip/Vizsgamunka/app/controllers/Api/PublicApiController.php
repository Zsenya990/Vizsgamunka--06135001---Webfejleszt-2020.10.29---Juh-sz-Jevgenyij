<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Core\HumanCheck;
use App\Core\Logger;
use App\Models\Appointment;
use App\Models\Timeslot;

class PublicApiController extends BaseController
{
    private const BOOKING_SELECTION_TTL = 300;

    private Appointment $appointment;
    private Timeslot $timeslot;

    public function __construct()
    {
        $this->appointment = new Appointment();
        $this->timeslot = new Timeslot();
    }

    public function startBookingSelection(): void
    {
        $data = $this->requestData();
        $timeslotId = (int) ($data['timeslot_id'] ?? 0);

        if ($timeslotId <= 0) {
            $this->json(['error' => 'invalid_timeslot_id'], 422);
            return;
        }

        if (!$this->timeslot->isFree($timeslotId)) {
            unset($_SESSION['booking_selection']);
            Logger::warning('booking', 'Attempted to start booking on unavailable timeslot', ['timeslot_id' => $timeslotId]);
            $this->json([
                'error' => 'timeslot_unavailable',
                'message' => 'Ez az idopont mar nem erheto el. Kerjuk, valasszon masikat.',
            ], 409);
            return;
        }

        $expiresAt = time() + self::BOOKING_SELECTION_TTL;
        $_SESSION['booking_selection'] = [
            'timeslot_id' => $timeslotId,
            'expires_at' => $expiresAt,
        ];
        $challenge = HumanCheck::refresh();
        Logger::info('booking', 'Booking selection started', ['timeslot_id' => $timeslotId, 'expires_at' => $expiresAt]);

        $this->json([
            'success' => true,
            'data' => [
                'timeslot_id' => $timeslotId,
                'expires_at' => $expiresAt,
                'duration_seconds' => self::BOOKING_SELECTION_TTL,
                'human_check' => $challenge,
            ],
        ], 201);
    }

    public function clearBookingSelection(): void
    {
        if (!empty($_SESSION['booking_selection']['timeslot_id'])) {
            Logger::info('booking', 'Booking selection cleared', ['timeslot_id' => (int) $_SESSION['booking_selection']['timeslot_id']]);
        }
        unset($_SESSION['booking_selection']);
        $this->json(['success' => true]);
    }

    public function createAppointment(): void
    {
        $data = $this->requestData();

        if (!empty($data['website'])) {
            Logger::warning('booking', 'Spam honeypot triggered');
            $this->json(['error' => 'spam_detected'], 422);
            return;
        }

        if (
            !isset($data['token'], $_SESSION['form_token']) ||
            !hash_equals($_SESSION['form_token'], (string) $data['token'])
        ) {
            Logger::warning('booking', 'Invalid public form token');
            $this->json(['error' => 'invalid_form'], 419);
            return;
        }

        $name = trim((string) ($data['name'] ?? ''));
        $email = trim((string) ($data['email'] ?? ''));
        $phone = trim((string) ($data['phone'] ?? ''));
        $message = trim((string) ($data['message'] ?? ''));
        $timeslotId = (int) ($data['timeslot_id'] ?? 0);
        $humanAnswer = trim((string) ($data['human_answer'] ?? ''));
        $selection = $_SESSION['booking_selection'] ?? null;

        $errors = [];
        if (strlen($name) < 3) {
            $errors[] = 'A nev legalabb 3 karakter legyen.';
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Ervenytelen e-mail cim.';
        }
        if (strlen($phone) < 6) {
            $errors[] = 'Nem megfelelo telefonszam formatum.';
        }
        if ($timeslotId <= 0) {
            $errors[] = 'Kerjuk, valasszon idopontot.';
        }
        if ($humanAnswer === '') {
            $errors[] = 'Kerjuk, valaszoljon a biztonsagi kerdesre.';
        } elseif (!HumanCheck::verify($humanAnswer)) {
            $errors[] = 'Hibas valasz a biztonsagi kerdesre.';
        }

        if ($errors !== []) {
            Logger::warning('booking', 'Booking validation failed', ['timeslot_id' => $timeslotId, 'errors' => $errors]);
            $this->json([
                'error' => 'validation_failed',
                'errors' => $errors,
                'humanCheck' => HumanCheck::refresh(),
            ], 422);
            return;
        }

        if (
            !is_array($selection) ||
            (int) ($selection['timeslot_id'] ?? 0) !== $timeslotId
        ) {
            Logger::warning('booking', 'Booking selection missing during submit', ['timeslot_id' => $timeslotId]);
            $this->json([
                'error' => 'selection_missing',
                'message' => 'A foglalasi folyamat megszakadt. Kerjuk, valasszon ujra idopontot.',
            ], 409);
            return;
        }

        if ((int) ($selection['expires_at'] ?? 0) < time()) {
            unset($_SESSION['booking_selection']);
            Logger::warning('booking', 'Booking selection expired', ['timeslot_id' => $timeslotId]);
            $this->json([
                'error' => 'selection_expired',
                'message' => 'Lejart az 5 perces foglalasi idokeret. Kerjuk, kezdje ujra a folyamatot.',
            ], 409);
            return;
        }

        if (!$this->timeslot->isFree($timeslotId)) {
            unset($_SESSION['booking_selection']);
            Logger::warning('booking', 'Booking timeslot became unavailable before submit', ['timeslot_id' => $timeslotId]);
            $this->json([
                'error' => 'timeslot_unavailable',
                'message' => 'Az idopont idokozben foglaltta valt. Kerjuk, valasszon uj idopontot.',
            ], 409);
            return;
        }

        $appointmentId = $this->appointment->createAndGetId($name, $email, $phone, $message, $timeslotId);
        if ($appointmentId === false) {
            Logger::warning('booking', 'Booking create failed because timeslot became unavailable', ['timeslot_id' => $timeslotId]);
            $this->json([
                'error' => 'timeslot_unavailable',
                'message' => 'Az idopont idokozben foglaltta valt. Kerjuk, valasszon uj idopontot.',
            ], 409);
            return;
        }

        $_SESSION['form_token'] = bin2hex(random_bytes(16));
        unset($_SESSION['booking_selection']);
        HumanCheck::clear();
        Logger::info('booking', 'Appointment created', [
            'appointment_id' => $appointmentId,
            'timeslot_id' => $timeslotId,
            'email' => $email,
        ]);

        $appointment = $this->appointment->getById($appointmentId);
        $this->json([
            'success' => true,
            'data' => $appointment,
            'redirect' => app_url('siker'),
        ], 201);
    }

    public function availabilityMonths(): void
    {
        $this->json($this->timeslot->getAvailableMonths());
    }

    public function availabilityDays(): void
    {
        $month = trim((string) ($_GET['month'] ?? ''));
        if ($month === '' || preg_match('/^\d{4}-\d{2}$/', $month) !== 1) {
            $this->json(['error' => 'invalid_month'], 422);
            return;
        }

        $this->json($this->timeslot->getAvailableDaysByMonth($month));
    }

    public function availabilityTimeslots(): void
    {
        $date = trim((string) ($_GET['date'] ?? ''));
        if ($date === '' || preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) !== 1) {
            $this->json(['error' => 'invalid_date'], 422);
            return;
        }

        $this->json($this->timeslot->getAvailableTimeslots($date));
    }

    public function availabilityTimeslot(string|int $id): void
    {
        $timeslot = $this->timeslot->getById((int) $id);
        if (!$timeslot) {
            $this->json(['error' => 'not_found'], 404);
            return;
        }

        $this->json([
            'id' => (int) $timeslot['id'],
            'timeslot' => (string) $timeslot['timeslot'],
            'is_booked' => (int) $timeslot['is_booked'],
            'available' => (int) $timeslot['is_booked'] === 0,
        ]);
    }
}
