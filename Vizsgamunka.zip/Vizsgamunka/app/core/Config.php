<?php

declare(strict_types=1);

namespace App\Core;

use RuntimeException;

final class Config
{
    private static ?array $env = null;

    public static function get(string $key, mixed $default = null): mixed
    {
        $env = self::env();
        return $env[$key] ?? $default;
    }

    public static function env(): array
    {
        if (self::$env !== null) {
            return self::$env;
        }

        $envPath = dirname(__DIR__, 2) . '/.env';
        if (!is_file($envPath)) {
            throw new RuntimeException('.env file not found.');
        }

        $env = parse_ini_file($envPath, false, INI_SCANNER_TYPED);
        if ($env === false) {
            throw new RuntimeException('.env file could not be parsed.');
        }

        self::$env = $env;
        return self::$env;
    }
}
