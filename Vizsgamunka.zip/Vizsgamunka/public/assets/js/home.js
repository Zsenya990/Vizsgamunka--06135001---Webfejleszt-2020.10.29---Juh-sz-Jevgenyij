document.addEventListener("DOMContentLoaded", function () {
    const baseUrl = window.APP_CONFIG?.baseUrl || "";
    const btn = document.getElementById("startBooking");
    const loading = document.getElementById("loadingAnim");

    if (!btn) return;

    btn.addEventListener("click", function () {
        btn.style.transform = "scale(0.95)";
        btn.style.opacity = "0.7";
        loading.style.display = "block";

        setTimeout(() => {
            window.location.href = `${baseUrl}/foglalas`;
        }, 1000);
    });
});
