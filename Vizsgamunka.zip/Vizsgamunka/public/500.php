<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Szerverhiba</title>
    <style>
        body { font-family: system-ui, sans-serif; background: #0f172a; color: #e5e7eb; margin: 0; display: grid; place-items: center; min-height: 100vh; }
        .box { max-width: 540px; padding: 2rem; border: 1px solid #334155; border-radius: 16px; background: #111827; box-shadow: 0 12px 30px rgba(0,0,0,.25); }
        h1 { margin-top: 0; }
        p { color: #cbd5e1; line-height: 1.6; }
        a { color: #93c5fd; }
    </style>
</head>
<body>
    <div class="box">
        <h1>Szerverhiba</h1>
        <p><?= htmlspecialchars($message ?? 'Varatlan hiba tortent.', ENT_QUOTES, 'UTF-8') ?></p>
        <p><a href="<?= htmlspecialchars(project_url(), ENT_QUOTES, 'UTF-8') ?>">Vissza a kezdooldalra</a></p>
    </div>
</body>
</html>
