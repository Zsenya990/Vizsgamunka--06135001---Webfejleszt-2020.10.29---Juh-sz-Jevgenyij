<?php

declare(strict_types=1);

namespace App\Models;

class Admin extends BaseModel
{
    public function getByUsername(string $username): array|false
    {
        return $this->fetch("SELECT * FROM users WHERE username = ?", [$username]);
    }

    public function verifyPassword(string $username, string $password): bool
    {
        $admin = $this->getByUsername($username);

        if (!$admin) {
            return false;
        }

        return password_verify($password, $admin['password']);
    }
}
