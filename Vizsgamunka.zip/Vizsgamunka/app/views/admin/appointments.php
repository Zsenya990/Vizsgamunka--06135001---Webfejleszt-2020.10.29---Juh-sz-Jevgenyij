<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Foglalasok</h2>

    <button class="btn btn-secondary d-flex align-items-center gap-2" id="refreshAppointmentsBtn" type="button">
        <span id="refreshIcon"><i class="bi bi-arrow-clockwise"></i></span>
        <span id="refreshSpinner" class="spinner-border spinner-border-sm d-none"></span>
        Frissites
    </button>
</div>

<div id="appointmentsGroups" class="d-grid gap-3">
    <div class="card shadow-sm p-3">
        <div class="text-muted">Foglalasok betoltese...</div>
    </div>
</div>

<div class="modal fade" id="appointmentModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" id="appointmentModalContent"></div>
    </div>
</div>
