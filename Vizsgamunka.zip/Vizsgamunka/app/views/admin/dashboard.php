<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold">Admin Dashboard</h2>
        <p class="text-muted">Attekintes es statisztikak</p>
    </div>
</div>

<hr class="my-4">

<h3 class="mb-4">Foglalasi grafikonok</h3>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card p-3 shadow-sm">
            <div class="d-flex align-items-center gap-2 justify-content-between mb-3">
                <button class="btn btn-outline-secondary btn-sm" id="prevFreeMonthBtn" type="button">
                    <i class="bi bi-chevron-left"></i>
                </button>
                <input
                    type="month"
                    id="freeMonth"
                    class="form-control"
                    value="<?= htmlspecialchars((string) $freeMonth, ENT_QUOTES, 'UTF-8') ?>"
                >
                <button class="btn btn-outline-secondary btn-sm" id="nextFreeMonthBtn" type="button">
                    <i class="bi bi-chevron-right"></i>
                </button>
            </div>
            <h5 class="mb-3">Havi szabad idopontok (%)</h5>
            <canvas id="freePercentChart"></canvas>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card p-3 shadow-sm">
            <div class="d-flex align-items-center gap-2 justify-content-between mb-3">
                <button class="btn btn-outline-secondary btn-sm" id="prevWeeklyMonthBtn" type="button">
                    <i class="bi bi-chevron-left"></i>
                </button>
                <input
                    type="month"
                    id="weeklyMonth"
                    class="form-control"
                    value="<?= htmlspecialchars((string) $weeklyMonth, ENT_QUOTES, 'UTF-8') ?>"
                >
                <button class="btn btn-outline-secondary btn-sm" id="nextWeeklyMonthBtn" type="button">
                    <i class="bi bi-chevron-right"></i>
                </button>
            </div>
            <h5 class="mb-3">Heti foglalasok (kivalasztott honap)</h5>
            <canvas id="weeklyChart"></canvas>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card p-3 shadow-sm">
            <div class="d-flex align-items-center gap-2 justify-content-between mb-3">
                <button class="btn btn-outline-secondary btn-sm" id="prevMonthlyYearBtn" type="button">
                    <i class="bi bi-chevron-left"></i>
                </button>
                <input
                    type="number"
                    id="monthlyYear"
                    class="form-control"
                    min="2000"
                    max="2100"
                    step="1"
                    value="<?= htmlspecialchars((string) $monthlyYear, ENT_QUOTES, 'UTF-8') ?>"
                >
                <button class="btn btn-outline-secondary btn-sm" id="nextMonthlyYearBtn" type="button">
                    <i class="bi bi-chevron-right"></i>
                </button>
            </div>
            <h5 class="mb-3">Havi foglalasok (kivalasztott ev)</h5>
            <canvas id="monthlyChart"></canvas>
        </div>
    </div>
</div>
