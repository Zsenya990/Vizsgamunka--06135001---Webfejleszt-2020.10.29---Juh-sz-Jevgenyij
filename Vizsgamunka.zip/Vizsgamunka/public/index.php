<?php

declare(strict_types=1);

date_default_timezone_set('Europe/Budapest');

ini_set('session.use_strict_mode', '1');

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

$scriptDirectory = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
$basePath = rtrim($scriptDirectory, '/');
if ($basePath === '' || $basePath === '.') {
    $basePath = '';
}

define('APP_BASE_PATH', $basePath);
define('APP_PROJECT_PATH', preg_replace('#/public$#', '', $basePath) ?: '');

if (PHP_SAPI !== 'cli') {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header("Content-Security-Policy: frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
}

function app_url(string $path = ''): string
{
    $path = trim($path, '/');

    if ($path === '') {
        return APP_BASE_PATH !== '' ? APP_BASE_PATH . '/' : '/';
    }

    return (APP_BASE_PATH !== '' ? APP_BASE_PATH : '') . '/' . $path;
}

function project_url(string $path = ''): string
{
    $path = trim($path, '/');

    if ($path === '') {
        return APP_PROJECT_PATH !== '' ? APP_PROJECT_PATH . '/' : '/';
    }

    return (APP_PROJECT_PATH !== '' ? APP_PROJECT_PATH : '') . '/' . $path;
}

function asset_url(string $path): string
{
    $path = trim($path, '/');
    $absolutePath = dirname(__DIR__) . '/' . $path;
    $version = is_file($absolutePath) ? (string) filemtime($absolutePath) : (string) time();

    return app_url($path) . '?v=' . $version;
}

if (PHP_SAPI !== 'cli' && str_ends_with(str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? ''), '/public/index.php')) {
    $route = trim((string) ($_GET['route'] ?? ''), '/');
    $target = project_url($route);

    if ($route === '') {
        $target = project_url();
    }

    header('Location: ' . $target, true, 302);
    exit;
}

spl_autoload_register(static function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $relativeClass = substr($class, strlen($prefix));
    $parts = explode('\\', $relativeClass);
    if (!empty($parts[0])) {
        $parts[0] = strtolower($parts[0]);
    }

    $relativePath = implode(DIRECTORY_SEPARATOR, $parts);
    $file = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . $relativePath . '.php';

    if (is_file($file)) {
        require_once $file;
    }
});

\App\Core\ErrorHandler::register();

require_once __DIR__ . '/core/router.php';

$router = new Router();

require __DIR__ . '/routes/api.php';
require __DIR__ . '/routes/web.php';
require __DIR__ . '/routes/admin.php';

$router->run();
