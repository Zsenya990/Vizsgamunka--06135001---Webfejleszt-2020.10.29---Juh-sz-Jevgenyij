<?php

require __DIR__ . '/api_public.php';
require __DIR__ . '/api_admin.php';
