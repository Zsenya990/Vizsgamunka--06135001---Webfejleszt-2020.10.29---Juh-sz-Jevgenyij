const baseUrl = window.APP_CONFIG?.baseUrl || "";

function esc(str) {
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

function loadAppointments() {
    const refreshIcon = document.getElementById("refreshIcon");
    const refreshSpinner = document.getElementById("refreshSpinner");
    if (refreshIcon) refreshIcon.classList.add("d-none");
    if (refreshSpinner) refreshSpinner.classList.remove("d-none");

    adminFetch(`${baseUrl}/api/appointments`)
        .then(data => renderAppointmentsTable(data))
        .catch(err => console.error("Hiba a foglalasok betoltesenel:", err))
        .finally(() => {
            if (refreshIcon) refreshIcon.classList.remove("d-none");
            if (refreshSpinner) refreshSpinner.classList.add("d-none");
        });
}

function renderAppointmentsTable(appointments) {
    const container = document.getElementById("appointmentsGroups");
    container.innerHTML = "";

    const groups = {
        uj: [],
        elfogadva: [],
        teljesult: [],
        torolve: []
    };

    appointments.forEach(appointment => {
        const status = normalizeStatus(appointment.allapot);
        if (groups[status]) {
            groups[status].push(appointment);
        } else {
            groups.uj.push(appointment);
        }
    });

    const definitions = [
        { key: "uj", title: "Nyitott foglalasok", open: true },
        { key: "elfogadva", title: "Elfogadott foglalasok", open: true },
        { key: "teljesult", title: "Teljesult foglalasok", open: false },
        { key: "torolve", title: "Torolt foglalasok", open: false }
    ];

    definitions.forEach(definition => {
        const section = document.createElement("details");
        section.className = "appointment-group card shadow-sm";
        if (definition.open) {
            section.open = true;
        }

        const items = groups[definition.key];
        section.innerHTML = `
            <summary class="appointment-group-summary">
                <span>${definition.title}</span>
                <span class="badge text-bg-secondary">${items.length}</span>
            </summary>
            <div class="appointment-group-body">
                ${items.length > 0 ? renderAppointmentsGroupTable(items) : '<div class="text-muted">Nincs foglalas ebben a kategoriaban.</div>'}
            </div>
        `;

        container.appendChild(section);
    });

    attachRowEvents();
}

function renderAppointmentsGroupTable(appointments) {
    return `
        <div class="table-responsive">
            <table class="table table-hover appointments-group-table mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nev</th>
                        <th>Email</th>
                        <th>Idopont</th>
                        <th>Allapot</th>
                        <th>Letrehozva</th>
                        <th class="text-end">Muveletek</th>
                    </tr>
                </thead>
                <tbody>
                    ${appointments.map(renderAppointmentRow).join("")}
                </tbody>
            </table>
        </div>
    `;
}

function renderAppointmentRow(a) {
    const normalizedStatus = normalizeStatus(a.allapot);
    let completeButton = "";
    let cancelButton = "";
    if (normalizedStatus === "elfogadva") {
        completeButton = `<button class="btn btn-sm btn-outline-success complete-btn" data-id="${a.id}">Teljesult</button>`;
    } else if (normalizedStatus === "teljesult") {
        completeButton = `<button class="btn btn-sm btn-outline-secondary" type="button" disabled>Teljesult</button>`;
    }

    if (normalizedStatus !== "torolve") {
        cancelButton = `<button class="btn btn-sm btn-outline-danger cancel-btn" data-id="${a.id}">Lemondott</button>`;
    }

    return `
        <tr>
            <td>${a.id}</td>
            <td>${esc(a.name)}</td>
            <td>${esc(a.email)}</td>
            <td>${a.timeslot ?? ""}</td>
            <td>${renderStatusBadge(a.allapot)}</td>
            <td>${a.created_at}</td>
            <td class="text-end">
                ${completeButton}
                ${cancelButton}
                <button class="btn btn-sm btn-primary view-btn" data-id="${a.id}">
                    <i class="bi bi-eye"></i>
                </button>
                <button class="btn btn-sm btn-secondary edit-btn" data-id="${a.id}">
                    <i class="bi bi-pencil"></i>
                </button>
                <button class="btn btn-sm btn-warning status-btn" data-id="${a.id}">
                    <i class="bi bi-arrow-repeat"></i>
                </button>
                <button class="btn btn-sm btn-danger delete-btn" data-id="${a.id}">
                    <i class="bi bi-trash"></i>
                </button>
            </td>
        </tr>
    `;
}

function normalizeStatus(status) {
    return String(status)
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase();
}

function renderStatusBadge(status) {
    const normalizedStatus = normalizeStatus(status);

    if (normalizedStatus === "uj") {
        return `<span class="badge bg-info">Uj</span>`;
    }
    if (normalizedStatus === "elfogadva") {
        return `<span class="badge bg-success">Elfogadva</span>`;
    }
    if (normalizedStatus === "teljesult") {
        return `<span class="badge bg-secondary">Teljesult</span>`;
    }
    return `<span class="badge bg-danger">Torolve</span>`;
}

function attachRowEvents() {
    document.querySelectorAll(".complete-btn").forEach(btn => {
        btn.addEventListener("click", () => markAppointmentCompleted(btn.dataset.id));
    });

    document.querySelectorAll(".cancel-btn").forEach(btn => {
        btn.addEventListener("click", () => markAppointmentCancelled(btn.dataset.id));
    });

    document.querySelectorAll(".view-btn").forEach(btn => {
        btn.addEventListener("click", () => openAppointmentModal(btn.dataset.id));
    });

    document.querySelectorAll(".edit-btn").forEach(btn => {
        btn.addEventListener("click", () => openEditAppointmentModal(btn.dataset.id));
    });

    document.querySelectorAll(".status-btn").forEach(btn => {
        btn.addEventListener("click", () => openStatusModal(btn.dataset.id));
    });

    document.querySelectorAll(".delete-btn").forEach(btn => {
        btn.addEventListener("click", () => deleteAppointment(btn.dataset.id));
    });
}

function openAppointmentModal(id) {
    const modalContent = document.querySelector("#appointmentModalContent");
    modalContent.innerHTML = "<div class='p-4 text-center text-muted'>Betoltes...</div>";

    adminFetchHtml(`${baseUrl}/admin/appointments/view/${id}`)
        .then(html => {
            modalContent.innerHTML = html;
            new bootstrap.Modal(document.getElementById("appointmentModal")).show();
        })
        .catch(err => console.error("Hiba a modal betoltesenel:", err));
}

function openStatusModal(id) {
    const modalContent = document.querySelector("#appointmentModalContent");
    modalContent.innerHTML = "<div class='p-4 text-center text-muted'>Betoltes...</div>";

    adminFetchHtml(`${baseUrl}/admin/appointments/status/${id}`)
        .then(html => {
            modalContent.innerHTML = html;
            const saveStatusBtn = document.getElementById("saveStatusBtn");
            if (saveStatusBtn) {
                saveStatusBtn.addEventListener("click", () => {
                    updateStatus(saveStatusBtn.dataset.appointmentId, document.getElementById("statusSelect")?.value || "");
                });
            }
            new bootstrap.Modal(document.getElementById("appointmentModal")).show();
        })
        .catch(err => console.error("Hiba a statusz modal betoltesenel:", err));
}

function openEditAppointmentModal(id) {
    const modalContent = document.querySelector("#appointmentModalContent");
    modalContent.innerHTML = "<div class='p-4 text-center text-muted'>Betoltes...</div>";

    adminFetchHtml(`${baseUrl}/admin/appointments/edit/${id}`)
        .then(html => {
            modalContent.innerHTML = html;
            const saveBtn = document.getElementById("saveAppointmentTimeslotBtn");
            if (saveBtn) {
                saveBtn.addEventListener("click", submitAppointmentTimeslotUpdate);
            }
            new bootstrap.Modal(document.getElementById("appointmentModal")).show();
        })
        .catch(err => console.error("Hiba az idopontszerkeszto modal betoltesenel:", err));
}

function updateStatus(id, newStatus) {
    adminFetch(`${baseUrl}/api/appointments/${id}`, {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ status: newStatus })
    })
        .then(result => {
            loadAppointments();

            const modalEl = document.getElementById("appointmentModal");
            const modal = bootstrap.Modal.getInstance(modalEl);
            if (modal) {
                modal.hide();
            }
        })
        .catch(err => {
            console.error("Hiba statuszvaltasnal:", err);
            alert(err.message || "A statusz modositasa nem sikerult.");
        });
}

function deleteAppointment(id) {
    if (!confirm("Biztosan torlod ezt a foglalast?")) return;

    adminFetch(`${baseUrl}/api/appointments/${id}`, {
        method: "DELETE"
    })
        .then(() => {
            loadAppointments();
        })
        .catch(err => {
            console.error("Hiba torlesnel:", err);
            alert(err.message || "Hiba tortent a torles soran.");
        });
}

function submitAppointmentTimeslotUpdate() {
    const form = document.getElementById("updateAppointmentTimeslotForm");
    if (!form) return;

    adminFetch(`${baseUrl}/api/appointments/${form.appointment_id.value}`, {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ timeslot_id: Number(form.timeslot_id.value) })
    })
        .then(result => {
            loadAppointments();

            const modalEl = document.getElementById("appointmentModal");
            const modal = bootstrap.Modal.getInstance(modalEl);
            if (modal) {
                modal.hide();
            }

            if (result.mailSent === false) {
                alert("Az idopont modositva lett, de az e-mail ertesites kuldese nem sikerult.");
            }
        })
        .catch(err => {
            console.error("Hiba idopontmodositasnal:", err);
            alert(err.message || "Hiba tortent az idopont modositasa kozben.");
        });
}

function markAppointmentCompleted(id) {
    if (!confirm("A szolgaltatas teljesult, atallitod a foglalast teljesult statuszra?")) return;

    updateStatus(id, "teljesult");
}

function markAppointmentCancelled(id) {
    if (!confirm("Biztosan lemondottra allitod ezt a foglalast?")) return;

    updateStatus(id, "torolve");
}

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("refreshAppointmentsBtn")?.addEventListener("click", loadAppointments);
    loadAppointments();
});
