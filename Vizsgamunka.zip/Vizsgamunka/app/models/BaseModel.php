<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;
use PDOStatement;

abstract class BaseModel
{
    protected PDO $pdo;

    public function __construct()
    {
        $this->pdo = Database::getConnection();
    }

    protected function fetchAll(string $sql, array $params = [], int $mode = PDO::FETCH_ASSOC): array
    {
        $stmt = $this->run($sql, $params);
        return $stmt->fetchAll($mode);
    }

    protected function fetch(string $sql, array $params = []): array|false
    {
        $stmt = $this->run($sql, $params);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    protected function fetchColumn(string $sql, array $params = []): mixed
    {
        $stmt = $this->run($sql, $params);
        return $stmt->fetchColumn();
    }

    protected function executeQuery(string $sql, array $params = []): bool
    {
        $stmt = $this->run($sql, $params);
        return $stmt->rowCount() >= 0;
    }

    protected function run(string $sql, array $params = []): PDOStatement
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }
}
