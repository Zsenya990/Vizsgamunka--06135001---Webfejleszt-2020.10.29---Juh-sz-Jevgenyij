document.addEventListener("DOMContentLoaded", () => {
    const baseUrl = window.APP_CONFIG?.baseUrl || "";
    const calendarGrid = document.getElementById("calendarGrid");
    const monthLabel = document.getElementById("monthLabel");
    const emptyState = document.getElementById("timeslotEmptyState");
    const bookingForm = document.getElementById("bookingForm");
    const selectedTimeslotInput = document.getElementById("selectedTimeslot");

    let currentDate = new Date();
    let selectedDate = null;

    const today = new Date();
    const TODAY_Y = today.getFullYear();
    const TODAY_M = today.getMonth();
    const TODAY_D = today.getDate();

    function renderCalendar() {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();

        const monthNames = [
            "januar", "februar", "marcius", "aprilis", "majus", "junius",
            "julius", "augusztus", "szeptember", "oktober", "november", "december"
        ];
        monthLabel.textContent = `${monthNames[month]} ${year}`;

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const startOffset = (firstDay === 0 ? 6 : firstDay - 1);

        calendarGrid.innerHTML = "";

        for (let i = 0; i < startOffset; i++) {
            const empty = document.createElement("div");
            empty.classList.add("calendar-day", "empty");
            empty.style.visibility = "hidden";
            calendarGrid.appendChild(empty);
        }

        for (let day = 1; day <= daysInMonth; day++) {
            const cell = document.createElement("div");
            cell.classList.add("calendar-day");
            cell.textContent = day;

            if (year === TODAY_Y && month === TODAY_M && day === TODAY_D) {
                cell.classList.add("today");
            }

            if (
                selectedDate &&
                selectedDate.year === year &&
                selectedDate.month === month &&
                selectedDate.day === day
            ) {
                cell.classList.add("selected");
            }

            cell.addEventListener("click", () => {
                document.querySelectorAll(".calendar-day").forEach(d => d.classList.remove("selected"));
                cell.classList.add("selected");
                selectedDate = { year, month, day };
                loadTimeslots(year, month, day);
            });

            calendarGrid.appendChild(cell);
        }
    }

    function loadTimeslots(year, month, day) {
        const slotContainer = document.getElementById("timeslotContainer");

        slotContainer.innerHTML = "";
        bookingForm.style.display = "none";
        selectedTimeslotInput.value = "";
        document.dispatchEvent(new CustomEvent("booking:selection-cleared"));

        const date = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;

        fetch(`${baseUrl}/api/availability/timeslots?date=${encodeURIComponent(date)}`)
            .then(res => res.json())
            .then(timeslots => {
                if (timeslots.length === 0) {
                    emptyState.textContent = "Erre a napra nincs rogzitett idopont.";
                    return;
                }

                emptyState.textContent = "Valassz egy szabad idopontot.";

                timeslots.forEach(slot => {
                    const div = document.createElement("div");
                    div.classList.add("timeslot");
                    div.textContent = slot.timeslot.substring(11, 16);

                    if (slot.is_booked == 1) {
                        div.classList.add("booked");
                        div.style.pointerEvents = "none";
                    } else {
                        div.addEventListener("click", async () => {
                            document.querySelectorAll(".timeslot").forEach(s => s.classList.remove("selected"));

                            try {
                                const response = await fetch(`${baseUrl}/api/booking-selection`, {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json"
                                    },
                                    body: JSON.stringify({ timeslot_id: Number(slot.id) })
                                });
                                const result = await response.json();

                                if (!response.ok || !result.success) {
                                    throw new Error(result.message || result.error || "Az idopont nem foglalhato.");
                                }

                                div.classList.add("selected");
                                selectedTimeslotInput.value = slot.id;
                                bookingForm.style.display = "block";
                                document.dispatchEvent(new CustomEvent("booking:selection-started", {
                                    detail: {
                                        timeslotId: Number(slot.id),
                                        expiresAt: Number(result.data?.expires_at || 0),
                                        durationSeconds: Number(result.data?.duration_seconds || 300),
                                        humanCheck: result.data?.human_check || null
                                    }
                                }));
                            } catch (error) {
                                selectedTimeslotInput.value = "";
                                bookingForm.style.display = "none";
                                emptyState.textContent = error.message || "Az idopont mar nem erheto el. Kerjuk, valasszon masikat.";
                            }
                        });
                    }

                    slotContainer.appendChild(div);
                });
            })
            .catch(() => {
                emptyState.textContent = "Nem sikerult betolteni az idopontokat.";
            });
    }

    document.getElementById("prevMonth").addEventListener("click", () => {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar();
    });

    document.getElementById("nextMonth").addEventListener("click", () => {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar();
    });

    renderCalendar();
});
