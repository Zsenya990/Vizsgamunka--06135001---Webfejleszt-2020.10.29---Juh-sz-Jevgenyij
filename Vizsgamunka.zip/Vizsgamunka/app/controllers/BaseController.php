<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\HttpException;
use App\Core\Logger;
use RuntimeException;

abstract class BaseController
{
    protected function csrfToken(string $key = 'csrf_token'): string
    {
        if (empty($_SESSION[$key]) || !is_string($_SESSION[$key])) {
            $_SESSION[$key] = bin2hex(random_bytes(32));
        }

        return $_SESSION[$key];
    }

    protected function validateCsrfToken(?string $token, string $key = 'csrf_token'): bool
    {
        return is_string($token)
            && $token !== ''
            && isset($_SESSION[$key])
            && is_string($_SESSION[$key])
            && hash_equals($_SESSION[$key], $token);
    }

    protected function sendNoCacheHeaders(): void
    {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
    }

    protected function render(string $view, array $data = [], string $layout = 'public'): void
    {
        $viewPath = dirname(__DIR__) . '/views/' . $view . '.php';
        $layoutPath = dirname(__DIR__) . '/views/layouts/' . $layout . '.php';

        if (!is_file($viewPath) || !is_file($layoutPath)) {
            throw new RuntimeException('View not found: ' . $view . ' [' . $layout . ']');
        }

        extract($data, EXTR_SKIP);
        $this->sendNoCacheHeaders();

        ob_start();
        require $viewPath;
        $content = ob_get_clean();

        require $layoutPath;
    }

    protected function renderPartial(string $view, array $data = []): void
    {
        $viewPath = dirname(__DIR__) . '/views/' . $view . '.php';

        if (!is_file($viewPath)) {
            throw new RuntimeException('Partial view not found: ' . $view);
        }

        extract($data, EXTR_SKIP);
        require $viewPath;
    }

    protected function json(array $payload, int $statusCode = 200): void
    {
        http_response_code($statusCode);
        $this->sendNoCacheHeaders();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    }

    protected function abort(int $statusCode, string $message = ''): never
    {
        throw new HttpException($statusCode, $message);
    }

    protected function redirect(string $path): void
    {
        header('Location: ' . app_url($path));
        exit;
    }

    protected function requestData(): array
    {
        $contentType = strtolower((string) ($_SERVER['CONTENT_TYPE'] ?? ''));
        if (str_contains($contentType, 'application/json')) {
            $raw = file_get_contents('php://input');
            if ($raw === false || trim($raw) === '') {
                return [];
            }

            $decoded = json_decode($raw, true);
            return is_array($decoded) ? $decoded : [];
        }

        if (!empty($_POST)) {
            return $_POST;
        }

        $raw = file_get_contents('php://input');
        if ($raw === false || trim($raw) === '') {
            return [];
        }

        parse_str($raw, $parsed);
        return is_array($parsed) ? $parsed : [];
    }

    protected function requireAdminApi(): bool
    {
        if (empty($_SESSION['admin_logged_in'])) {
            Logger::warning('auth', 'Unauthorized admin API access', ['reason' => 'not_logged_in']);
            $this->json(['error' => 'unauthorized'], 401);
            return false;
        }

        $requestIp = $_SERVER['REMOTE_ADDR'] ?? '';
        $requestUserAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

        if (
            !isset($_SESSION['admin_ip'], $_SESSION['admin_ua']) ||
            $_SESSION['admin_ip'] !== $requestIp ||
            $_SESSION['admin_ua'] !== $requestUserAgent
        ) {
            Logger::warning('auth', 'Admin session rejected', ['reason' => 'fingerprint_mismatch']);
            $this->logoutAdmin();
            $this->json(['error' => 'unauthorized'], 401);
            return false;
        }

        if (isset($_SESSION['last_activity']) && (time() - (int) $_SESSION['last_activity']) > 1800) {
            Logger::warning('auth', 'Admin API session expired');
            $this->logoutAdmin();
            $this->json(['error' => 'session_expired'], 401);
            return false;
        }

        $this->refreshAdminSession();

        $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
        if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
            $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null;
            if (!$this->validateCsrfToken(is_string($token) ? $token : null, 'admin_csrf_token')) {
                Logger::warning('auth', 'Admin API CSRF validation failed', ['method' => $method]);
                $this->json(['error' => 'invalid_csrf_token'], 419);
                return false;
            }
        }

        return true;
    }

    protected function requireAdmin(): void
    {
        if (empty($_SESSION['admin_logged_in'])) {
            $this->redirect('/admin/login');
        }

        $requestIp = $_SERVER['REMOTE_ADDR'] ?? '';
        $requestUserAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

        if (
            !isset($_SESSION['admin_ip'], $_SESSION['admin_ua']) ||
            $_SESSION['admin_ip'] !== $requestIp ||
            $_SESSION['admin_ua'] !== $requestUserAgent
        ) {
            Logger::warning('auth', 'Admin page session rejected', ['reason' => 'fingerprint_mismatch']);
            $this->logoutAdmin();
            $this->redirect('/admin/login');
        }

        if (isset($_SESSION['last_activity']) && (time() - (int) $_SESSION['last_activity']) > 1800) {
            Logger::warning('auth', 'Admin page session expired');
            $this->logoutAdmin();
            $this->redirect('/admin/login?timeout=1');
        }

        $this->refreshAdminSession();
    }

    protected function guestOnly(): void
    {
        if (!empty($_SESSION['admin_logged_in'])) {
            $this->redirect('/admin');
        }
    }

    protected function logoutAdmin(): void
    {
        $_SESSION = [];

        if (session_status() === PHP_SESSION_ACTIVE) {
            if (ini_get('session.use_cookies')) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', [
                    'expires' => time() - 42000,
                    'path' => $params['path'],
                    'domain' => $params['domain'] ?? '',
                    'secure' => (bool) $params['secure'],
                    'httponly' => (bool) $params['httponly'],
                    'samesite' => $params['samesite'] ?? 'Strict',
                ]);
            }
            session_destroy();
        }
    }

    protected function refreshAdminSession(): void
    {
        $now = time();
        if (!isset($_SESSION['last_regeneration'])) {
            $_SESSION['last_regeneration'] = $now;
        }

        if (($now - (int) $_SESSION['last_regeneration']) >= 300) {
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = $now;
        }

        $_SESSION['last_activity'] = $now;
    }
}
