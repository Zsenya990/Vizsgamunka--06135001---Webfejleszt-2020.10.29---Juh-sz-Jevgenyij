<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="fw-bold">Osszegzes</h2>
        <p class="text-muted">Foglalasok es idopontok statisztikai</p>
    </div>

    <form class="d-flex gap-2" method="get" action="<?= htmlspecialchars(app_url('admin/export/appointments'), ENT_QUOTES, 'UTF-8') ?>">
        <select name="status" class="form-select">
            <option value="">Osszes statusz</option>
            <option value="uj">Uj</option>
            <option value="elfogadva">Elfogadva</option>
            <option value="teljesult">Teljesult</option>
            <option value="torolve">Torolve</option>
        </select>

        <input type="month" name="month" class="form-control">

        <button class="btn btn-success" type="submit">
            <i class="bi bi-file-earmark-spreadsheet"></i> Export CSV
        </button>
    </form>
</div>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card shadow text-center p-3">
            <h5 class="text-secondary">Osszes foglalas</h5>
            <h2 class="fw-bold" id="totalAppointments">0</h2>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow text-center p-3 border-primary">
            <h5 class="text-primary">Uj foglalasok</h5>
            <h2 class="fw-bold" id="newAppointments">0</h2>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow text-center p-3 border-success">
            <h5 class="text-success">Elfogadva</h5>
            <h2 class="fw-bold" id="acceptedAppointments">0</h2>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow text-center p-3 border-secondary">
            <h5 class="text-secondary">Teljesult</h5>
            <h2 class="fw-bold" id="completedAppointments">0</h2>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow text-center p-3 border-danger">
            <h5 class="text-danger">Torolve</h5>
            <h2 class="fw-bold" id="rejectedAppointments">0</h2>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow text-center p-3 border-info">
            <h5 class="text-info">Szabad idopontok</h5>
            <h2 class="fw-bold" id="freeSlots">0</h2>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow text-center p-3 border-warning">
            <h5 class="text-warning">Foglalt idopontok</h5>
            <h2 class="fw-bold" id="bookedSlots">0</h2>
        </div>
    </div>
</div>

<hr class="my-5">

<div class="row g-4">
    <div class="col-md-4">
        <div class="card shadow-sm p-3">
            <h5 class="mb-3">Foglalasok allapot szerint</h5>
            <canvas id="statusChart" height="200"></canvas>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow-sm p-3">
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                <h5 class="mb-0">Napi foglalasszam</h5>
                <div class="d-flex align-items-center gap-2">
                    <button class="btn btn-outline-secondary btn-sm" id="prevDailyMonthBtn" type="button">
                        <i class="bi bi-chevron-left"></i>
                    </button>
                    <input type="month" id="dailyMonth" class="form-control" value="<?= htmlspecialchars((string) $dailyMonth, ENT_QUOTES, 'UTF-8') ?>">
                    <button class="btn btn-outline-secondary btn-sm" id="nextDailyMonthBtn" type="button">
                        <i class="bi bi-chevron-right"></i>
                    </button>
                </div>
            </div>
            <canvas id="dailyChart" height="200"></canvas>
        </div>
    </div>
</div>
