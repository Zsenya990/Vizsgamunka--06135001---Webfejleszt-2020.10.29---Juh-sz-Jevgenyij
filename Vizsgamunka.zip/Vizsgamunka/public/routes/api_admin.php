<?php

use App\Controllers\Api\AdminApiController;

$router->get('api/appointments', [AdminApiController::class, 'listAppointments']);
$router->get('api/appointments/{id}', [AdminApiController::class, 'getAppointment']);
$router->patch('api/appointments/{id}', [AdminApiController::class, 'updateAppointment']);
$router->put('api/appointments/{id}', [AdminApiController::class, 'updateAppointment']);
$router->delete('api/appointments/{id}', [AdminApiController::class, 'deleteAppointment']);

$router->get('api/timeslots', [AdminApiController::class, 'listTimeslots']);
$router->get('api/timeslots/{id}', [AdminApiController::class, 'getTimeslot']);
$router->post('api/timeslots', [AdminApiController::class, 'createTimeslot']);
$router->patch('api/timeslots/{id}', [AdminApiController::class, 'updateTimeslot']);
$router->put('api/timeslots/{id}', [AdminApiController::class, 'updateTimeslot']);
$router->delete('api/timeslots/{id}', [AdminApiController::class, 'deleteTimeslot']);
$router->post('api/timeslots/generate', [AdminApiController::class, 'generateTimeslots']);
$router->post('api/timeslots/refresh', [AdminApiController::class, 'refreshTimeslots']);

$router->get('api/dashboard/summary', [AdminApiController::class, 'dashboardSummary']);
$router->get('api/dashboard/charts', [AdminApiController::class, 'dashboardCharts']);
