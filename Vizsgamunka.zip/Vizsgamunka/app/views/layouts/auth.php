<?php
$pageTitle = $title ?? 'Admin bejelentkezes';
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= htmlspecialchars(asset_url('public/assets/admin/css/login.css'), ENT_QUOTES, 'UTF-8') ?>">
</head>
<body class="admin-auth" data-app-section="admin-auth">
<main class="container py-5">
    <?= $content ?>
</main>
</body>
</html>
