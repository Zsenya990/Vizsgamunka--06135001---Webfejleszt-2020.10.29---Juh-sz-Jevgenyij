const baseUrl = window.APP_CONFIG?.baseUrl || "";

let freeChart = null;
let weeklyChart = null;
let monthlyChart = null;

function getInputValue(id, fallback) {
    return document.getElementById(id)?.value || fallback;
}

function shiftMonth(month, offset) {
    const [year, monthNumber] = month.split("-").map(Number);
    const date = new Date(year, monthNumber - 1 + offset, 1);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function updateDashboardUrl() {
    const url = new URL(window.location.href);
    url.searchParams.set("route", "admin");
    url.searchParams.set("free_month", getInputValue("freeMonth", new Date().toISOString().slice(0, 7)));
    url.searchParams.set("weekly_month", getInputValue("weeklyMonth", new Date().toISOString().slice(0, 7)));
    url.searchParams.set("monthly_year", getInputValue("monthlyYear", String(new Date().getFullYear())));
    window.history.replaceState({}, "", url);
}

function renderFreeChart(data) {
    if (freeChart) freeChart.destroy();
    freeChart = new Chart(document.getElementById("freePercentChart"), {
        type: "doughnut",
        data: {
            labels: ["Szabad (%)", "Foglalt (%)"],
            datasets: [{
                data: [data.monthlyFreePercent ?? 0, data.monthlyBookedPercent ?? 0],
                backgroundColor: ["rgba(25, 135, 84, 0.8)", "rgba(220, 53, 69, 0.8)"],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { position: "bottom" } }
        }
    });
}

function renderWeeklyChart(data) {
    if (weeklyChart) weeklyChart.destroy();
    weeklyChart = new Chart(document.getElementById("weeklyChart"), {
        type: "bar",
        data: {
            labels: data.weekly?.map(item => item.week_start) ?? [],
            datasets: [{
                label: "Foglalasok szama",
                data: data.weekly?.map(item => item.count) ?? [],
                backgroundColor: "rgba(13,110,253,0.7)",
                borderColor: "#0d6efd",
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true } }
        }
    });
}

function renderMonthlyChart(data) {
    if (monthlyChart) monthlyChart.destroy();
    monthlyChart = new Chart(document.getElementById("monthlyChart"), {
        type: "bar",
        data: {
            labels: data.monthly?.map(item => item.month) ?? [],
            datasets: [{
                label: "Foglalasok szama",
                data: data.monthly?.map(item => item.count) ?? [],
                backgroundColor: "rgba(255,159,64,0.7)",
                borderColor: "rgb(255,159,64)",
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true } }
        }
    });
}

function loadCharts(target = "all") {
    const freeMonth = getInputValue("freeMonth", new Date().toISOString().slice(0, 7));
    const weeklyMonth = getInputValue("weeklyMonth", new Date().toISOString().slice(0, 7));
    const monthlyYear = getInputValue("monthlyYear", String(new Date().getFullYear()));

    updateDashboardUrl();

    adminFetch(`${baseUrl}/api/dashboard/charts?free_month=${encodeURIComponent(freeMonth)}&weekly_month=${encodeURIComponent(weeklyMonth)}&monthly_year=${encodeURIComponent(monthlyYear)}`)
        .then(data => {
            if (target === "all" || target === "free") {
                renderFreeChart(data);
            }
            if (target === "all" || target === "weekly") {
                renderWeeklyChart(data);
            }
            if (target === "all" || target === "monthly") {
                renderMonthlyChart(data);
            }
        })
        .catch(err => console.error("Dashboard chart hiba:", err));
}

function bindMonthShift(inputId, prevBtnId, nextBtnId) {
    const input = document.getElementById(inputId);
    const prevBtn = document.getElementById(prevBtnId);
    const nextBtn = document.getElementById(nextBtnId);
    const target = inputId === "freeMonth" ? "free" : "weekly";

    if (input) {
        input.addEventListener("change", () => loadCharts(target));
    }

    if (prevBtn && input) {
        prevBtn.addEventListener("click", () => {
            input.value = shiftMonth(input.value, -1);
            loadCharts(target);
        });
    }

    if (nextBtn && input) {
        nextBtn.addEventListener("click", () => {
            input.value = shiftMonth(input.value, 1);
            loadCharts(target);
        });
    }
}

function bindYearShift() {
    const input = document.getElementById("monthlyYear");
    const prevBtn = document.getElementById("prevMonthlyYearBtn");
    const nextBtn = document.getElementById("nextMonthlyYearBtn");

    if (input) {
        input.addEventListener("change", () => loadCharts("monthly"));
    }

    if (prevBtn && input) {
        prevBtn.addEventListener("click", () => {
            input.value = String((Number(input.value) || new Date().getFullYear()) - 1);
            loadCharts("monthly");
        });
    }

    if (nextBtn && input) {
        nextBtn.addEventListener("click", () => {
            input.value = String((Number(input.value) || new Date().getFullYear()) + 1);
            loadCharts("monthly");
        });
    }
}

document.addEventListener("DOMContentLoaded", () => {
    bindMonthShift("freeMonth", "prevFreeMonthBtn", "nextFreeMonthBtn");
    bindMonthShift("weeklyMonth", "prevWeeklyMonthBtn", "nextWeeklyMonthBtn");
    bindYearShift();
    loadCharts();
});
