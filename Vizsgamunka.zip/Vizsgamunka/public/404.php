<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Az oldal nem talalhato</title>
</head>
<body>
    <section class="error-shell">
        <div class="error-grid">
            <div class="error-code">404</div>
            <div class="error-content">
                <div class="eyebrow">Nem talalhato</div>
                <h1>Ez az oldal nincs a rendszerben.</h1>
                <p>A keresett URL vagy mar nem letezik, vagy hibas cimen lett megnyitva.</p>
                <p>Erdemes visszaterni a publikus kezdooldalra, vagy tovabblepni az admin dashboardra, ha oda szerettel volna jutni.</p>
                <div class="actions">
                    <a class="btn btn-primary" href="<?= htmlspecialchars(project_url(), ENT_QUOTES, 'UTF-8') ?>">Kezdooldal</a>
                    <a class="btn btn-secondary" href="<?= htmlspecialchars(app_url('admin'), ENT_QUOTES, 'UTF-8') ?>">Admin felulet</a>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
