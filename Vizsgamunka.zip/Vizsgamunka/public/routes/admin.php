<?php

use App\Controllers\AdminController;
use App\Controllers\AuthController;

$router->get('admin', [AdminController::class, 'dashboard']);
$router->get('admin/dashboard', static function (): void {
    header('Location: ' . app_url('admin'), true, 302);
    exit;
});

$router->get('admin/summary', [AdminController::class, 'summary']);
$router->get('admin/logs', [AdminController::class, 'logs']);

$router->get('admin/timeslots', [AdminController::class, 'timeslots']);
$router->get('admin/timeslots/edit/{id}', [AdminController::class, 'editTimeslot']);

$router->get('admin/appointments', [AdminController::class, 'appointments']);
$router->get('admin/appointments/view/{id}', [AdminController::class, 'viewAppointment']);
$router->get('admin/appointments/edit/{id}', [AdminController::class, 'editAppointment']);
$router->get('admin/appointments/status/{id}', [AdminController::class, 'statusModal']);

$router->get('admin/export/appointments', [AdminController::class, 'exportAppointments']);
$router->get('admin/export/logs', [AdminController::class, 'exportLogs']);

$router->get('admin/login', [AuthController::class, 'adminLogin']);
$router->post('admin/login', [AuthController::class, 'adminLoginPost']);
$router->post('admin/logout', [AuthController::class, 'adminLogout']);
