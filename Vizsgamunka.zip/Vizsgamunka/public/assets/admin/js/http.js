const adminBaseUrl = window.APP_CONFIG?.baseUrl || "";
const adminCsrfToken = window.APP_CONFIG?.csrfToken || "";

async function adminFetch(url, options = {}) {
    const normalizedOptions = { ...options };
    const method = String(normalizedOptions.method || "GET").toUpperCase();
    const headers = new Headers(normalizedOptions.headers || {});

    if (["POST", "PUT", "PATCH", "DELETE"].includes(method) && adminCsrfToken !== "") {
        headers.set("X-CSRF-Token", adminCsrfToken);
    }

    normalizedOptions.method = method;
    normalizedOptions.headers = headers;
    normalizedOptions.credentials = "same-origin";
    normalizedOptions.cache = "no-store";

    const response = await fetch(url, normalizedOptions);
    const data = await response.json().catch(() => null);

    if (!response.ok) {
        if (response.status === 401 || response.status === 419) {
            window.location.href = `${adminBaseUrl}/admin/login?timeout=1`;
        }

        const error = new Error(data?.message || data?.error || `HTTP ${response.status}`);
        error.payload = data;
        error.status = response.status;
        throw error;
    }

    return data;
}

async function adminFetchHtml(url) {
    const response = await fetch(url, {
        credentials: "same-origin",
        cache: "no-store",
        headers: {
            "X-Requested-With": "XMLHttpRequest"
        }
    });
    const html = await response.text();

    if (response.redirected || response.url.includes("/admin/login")) {
        window.location.href = `${adminBaseUrl}/admin/login?timeout=1`;
        throw new Error("unauthorized");
    }

    if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
    }

    return html;
}
