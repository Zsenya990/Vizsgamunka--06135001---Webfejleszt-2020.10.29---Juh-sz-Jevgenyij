<?php

use App\Controllers\BookingController;
use App\Controllers\HomeController;

$router->get('/', [HomeController::class, 'index']);
$router->get('foglalas', [BookingController::class, 'index']);

$router->get('kapcsolat', [HomeController::class, 'contact']);
$router->post('kapcsolat', [HomeController::class, 'contactSubmit']);
$router->get('siker', [HomeController::class, 'success']);
