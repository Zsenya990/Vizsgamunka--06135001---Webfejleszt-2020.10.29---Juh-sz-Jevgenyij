<?php

declare(strict_types=1);

namespace App\Core;

final class Logger
{
    public static function info(string $category, string $message, array $context = []): void
    {
        self::write('info', $category, $message, $context);
    }

    public static function warning(string $category, string $message, array $context = []): void
    {
        self::write('warning', $category, $message, $context);
    }

    public static function error(string $category, string $message, array $context = []): void
    {
        self::write('error', $category, $message, $context);
    }

    private static function write(string $level, string $category, string $message, array $context = []): void
    {
        $directory = dirname(__DIR__, 2) . '/storage/logs';
        if (!is_dir($directory)) {
            mkdir($directory, 0775, true);
        }

        $record = [
            'timestamp' => date('c'),
            'level' => $level,
            'category' => $category,
            'message' => $message,
            'context' => self::sanitizeContext($context),
            'ip' => (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
            'user_agent' => (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''),
            'request_uri' => (string) ($_SERVER['REQUEST_URI'] ?? ''),
            'method' => (string) ($_SERVER['REQUEST_METHOD'] ?? ''),
        ];

        file_put_contents(
            $directory . '/app-' . date('Y-m-d') . '.log',
            json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL,
            FILE_APPEND | LOCK_EX
        );
    }

    private static function sanitizeContext(array $context): array
    {
        $sanitized = [];

        foreach ($context as $key => $value) {
            if (in_array((string) $key, ['password', 'csrf_token', 'token', 'human_answer'], true)) {
                $sanitized[$key] = '[redacted]';
                continue;
            }

            if (is_scalar($value) || $value === null) {
                $sanitized[$key] = $value;
                continue;
            }

            $sanitized[$key] = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }

        return $sanitized;
    }
}
