const baseUrl = window.APP_CONFIG?.baseUrl || "";

let weekGroups = [];
let currentWeekIndex = 0;

function getMonthPicker() {
    return document.getElementById("timeslotsMonthPicker");
}

function getSelectedMonth() {
    return getMonthPicker()?.value || new Date().toISOString().slice(0, 7);
}

function shiftMonth(month, offset) {
    const [year, monthNumber] = month.split("-").map(Number);
    const date = new Date(year, monthNumber - 1 + offset, 1);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function getWeekStart(date) {
    const copy = new Date(date);
    const day = copy.getDay();
    const diff = day === 0 ? -6 : 1 - day;
    copy.setDate(copy.getDate() + diff);
    copy.setHours(0, 0, 0, 0);
    return copy;
}

function formatIsoDate(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function formatWeekLabel(weekKey) {
    const start = new Date(`${weekKey}T00:00:00`);
    const end = new Date(start);
    end.setDate(end.getDate() + 6);
    return `${start.toLocaleDateString("hu-HU")} - ${end.toLocaleDateString("hu-HU")}`;
}

function updateUrl() {
    const url = new URL(window.location.href);
    url.searchParams.set("route", "admin/timeslots");
    url.searchParams.set("month", getSelectedMonth());
    url.searchParams.delete("week");
    window.history.replaceState({}, "", url);
}

function groupTimeslotsByWeek(timeslots) {
    const groups = new Map();

    timeslots.forEach(slot => {
        const weekKey = formatIsoDate(getWeekStart(new Date(slot.timeslot)));
        if (!groups.has(weekKey)) {
            groups.set(weekKey, []);
        }
        groups.get(weekKey).push(slot);
    });

    return Array.from(groups.entries()).map(([weekKey, slots]) => ({ weekKey, slots }));
}

function updateWeekUi() {
    const weekLabel = document.getElementById("timeslotsWeekLabel");
    const weekCounter = document.getElementById("timeslotsWeekCounter");
    const prevWeekBtn = document.getElementById("prevWeekBtn");
    const nextWeekBtn = document.getElementById("nextWeekBtn");

    if (weekGroups.length === 0) {
        if (weekLabel) weekLabel.textContent = "Nincs heti szakasz";
        if (weekCounter) weekCounter.textContent = "";
        if (prevWeekBtn) prevWeekBtn.disabled = true;
        if (nextWeekBtn) nextWeekBtn.disabled = true;
        updateUrl();
        return;
    }

    const currentGroup = weekGroups[currentWeekIndex];
    if (weekLabel) {
        weekLabel.textContent = formatWeekLabel(currentGroup.weekKey);
    }
    if (weekCounter) {
        weekCounter.textContent = `${currentWeekIndex + 1} / ${weekGroups.length}. het`;
    }
    if (prevWeekBtn) {
        prevWeekBtn.disabled = currentWeekIndex === 0;
    }
    if (nextWeekBtn) {
        nextWeekBtn.disabled = currentWeekIndex >= weekGroups.length - 1;
    }

    updateUrl();
}

function loadTimeslots() {
    const refreshIcon = document.getElementById("refreshIcon");
    const refreshSpinner = document.getElementById("refreshSpinner");
    if (refreshIcon) refreshIcon.classList.add("d-none");
    if (refreshSpinner) refreshSpinner.classList.remove("d-none");

    adminFetch(`${baseUrl}/api/timeslots?month=${encodeURIComponent(getSelectedMonth())}`)
        .then(data => {
            weekGroups = groupTimeslotsByWeek(Array.isArray(data) ? data : []);
            currentWeekIndex = 0;
            renderCurrentWeek();
        })
        .catch(err => console.error("Hiba a timeslot betoltesenel:", err))
        .finally(() => {
            if (refreshIcon) refreshIcon.classList.remove("d-none");
            if (refreshSpinner) refreshSpinner.classList.add("d-none");
        });
}

function renderCurrentWeek() {
    const timeslots = weekGroups[currentWeekIndex]?.slots ?? [];
    const tbody = document.querySelector("#timeslotsTable tbody");
    const emptyState = document.getElementById("timeslotsEmptyState");
    tbody.innerHTML = "";

    updateWeekUi();

    if (timeslots.length === 0) {
        if (emptyState) {
            emptyState.classList.remove("d-none");
        }
        return;
    }

    if (emptyState) {
        emptyState.classList.add("d-none");
    }

    timeslots.forEach(slot => {
        const dt = new Date(slot.timeslot);
        const date = dt.toLocaleDateString("hu-HU");
        const time = dt.toLocaleTimeString("hu-HU", { hour: "2-digit", minute: "2-digit" });

        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${slot.id}</td>
            <td>${date} ${time}</td>
            <td>${slot.is_booked == 1 ? '<span class="badge bg-danger">Foglalt</span>' : '<span class="badge bg-success">Szabad</span>'}</td>
            <td class="text-end">
                <button class="btn btn-warning btn-sm edit-btn" data-id="${slot.id}">
                    <i class="bi bi-pencil"></i>
                </button>
                <button class="btn btn-danger btn-sm delete-btn" data-id="${slot.id}">
                    <i class="bi bi-trash"></i>
                </button>
            </td>
        `;

        tbody.appendChild(tr);
    });

    attachRowEvents();
}

function attachRowEvents() {
    document.querySelectorAll(".edit-btn").forEach(btn => {
        btn.addEventListener("click", () => openEditModal(btn.dataset.id));
    });

    document.querySelectorAll(".delete-btn").forEach(btn => {
        btn.addEventListener("click", () => deleteTimeslot(btn.dataset.id));
    });
}

function openEditModal(id) {
    adminFetchHtml(`${baseUrl}/admin/timeslots/edit/${id}`)
        .then(html => {
            document.getElementById("timeslotModalContent").innerHTML = html;
            const modal = new bootstrap.Modal(document.getElementById("timeslotModal"));
            modal.show();

            const form = document.getElementById("updateTimeslotForm");
            if (form) {
                form.addEventListener("submit", function (e) {
                    updateTimeslot(e, modal);
                });
            }
        });
}

function updateTimeslot(event, modal) {
    event.preventDefault();

    const form = event.target;
    adminFetch(`${baseUrl}/api/timeslots/${form.id.value}`, {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ timeslot: form.timeslot.value })
    })
        .then(data => {
            modal.hide();
            loadTimeslots();
        })
        .catch(err => {
            console.error("Hiba mentesnel:", err);
            if (err.message === "timeslot_conflict") {
                alert("Mar letezik ilyen idopont. Valassz masik idosavot.");
                return;
            }
            alert("Hiba tortent a mentes soran.");
        });
}

function deleteTimeslot(id) {
    if (!confirm("Biztosan torlod ezt az idosavot?")) return;

    adminFetch(`${baseUrl}/api/timeslots/${id}`, {
        method: "DELETE"
    })
        .then(() => {
            loadTimeslots();
        })
        .catch(err => {
            console.error("Hiba torlesnel:", err);
            if (err.message === "timeslot_in_use") {
                alert("Ez az idopont hasznalatban van, ezert nem torolheto.");
                return;
            }
            alert("Hiba tortent a torles soran.");
        });
}

function generateTimeslots(event) {
    event.preventDefault();

    adminFetch(`${baseUrl}/api/timeslots/generate`, {
        method: "POST",
        body: new FormData(event.target)
    })
        .then(() => {
            event.target.reset();
            loadTimeslots();
        })
        .catch(err => {
            console.error("Hiba generalasnal:", err);
            alert(err.message || "Hiba tortent a generalas soran.");
        });
}

function refreshTimeslots(event) {
    event.preventDefault();

    adminFetch(`${baseUrl}/api/timeslots/refresh`, {
        method: "POST"
    })
        .then(() => {
            loadTimeslots();
        })
        .catch(err => {
            console.error("Hiba frissitesnel:", err);
            alert(err.message || "Hiba tortent a frissites soran.");
        });
}

function bindMonthControls() {
    const monthPicker = getMonthPicker();
    const prevBtn = document.getElementById("prevMonthBtn");
    const nextBtn = document.getElementById("nextMonthBtn");
    const prevWeekBtn = document.getElementById("prevWeekBtn");
    const nextWeekBtn = document.getElementById("nextWeekBtn");

    if (monthPicker) {
        monthPicker.addEventListener("change", () => {
            currentWeekIndex = 0;
            loadTimeslots();
        });
    }

    if (prevBtn) {
        prevBtn.addEventListener("click", () => {
            monthPicker.value = shiftMonth(getSelectedMonth(), -1);
            currentWeekIndex = 0;
            loadTimeslots();
        });
    }

    if (nextBtn) {
        nextBtn.addEventListener("click", () => {
            monthPicker.value = shiftMonth(getSelectedMonth(), 1);
            currentWeekIndex = 0;
            loadTimeslots();
        });
    }

    if (prevWeekBtn) {
        prevWeekBtn.addEventListener("click", () => {
            if (currentWeekIndex > 0) {
                currentWeekIndex -= 1;
                renderCurrentWeek();
            }
        });
    }

    if (nextWeekBtn) {
        nextWeekBtn.addEventListener("click", () => {
            if (currentWeekIndex < weekGroups.length - 1) {
                currentWeekIndex += 1;
                renderCurrentWeek();
            }
        });
    }
}

document.addEventListener("DOMContentLoaded", () => {
    bindMonthControls();
    document.getElementById("refreshTimeslotsBtn")?.addEventListener("click", loadTimeslots);
    document.getElementById("generateForm")?.addEventListener("submit", generateTimeslots);
    document.getElementById("refreshForm")?.addEventListener("submit", refreshTimeslots);
    loadTimeslots();
});
