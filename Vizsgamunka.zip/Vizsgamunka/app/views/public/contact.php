<div class="card shadow p-4">
    <h1 class="text-center mb-4">Kapcsolat</h1>
    <?php $old = $old ?? ['name' => '', 'email' => '', 'message' => '']; ?>

    <?php if (!empty($sent)): ?>
        <div class="alert alert-success">Uzenetedet rogzitettuk. Koszonjuk.</div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars((string) $error, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <?php if (!empty($errors) && is_array($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $validationError): ?>
                    <li><?= htmlspecialchars((string) $validationError, ENT_QUOTES, 'UTF-8') ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="<?= htmlspecialchars(app_url('kapcsolat'), ENT_QUOTES, 'UTF-8') ?>">

        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string) ($csrfToken ?? ''), ENT_QUOTES, 'UTF-8') ?>">

        <div class="mb-3">
            <label class="form-label" for="contactName">Nev</label>
            <input id="contactName" type="text" name="name" class="form-control" required value="<?= htmlspecialchars((string) ($old['name'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        </div>

        <div class="mb-3">
            <label class="form-label" for="contactEmail">E-mail cim</label>
            <input id="contactEmail" type="email" name="email" class="form-control" required value="<?= htmlspecialchars((string) ($old['email'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        </div>

        <div class="mb-3">
            <label class="form-label" for="contactMessage">Uzenet</label>
            <textarea id="contactMessage" name="message" class="form-control" rows="5" required><?= htmlspecialchars((string) ($old['message'] ?? ''), ENT_QUOTES, 'UTF-8') ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary w-100">Uzenet kuldese</button>
    </form>
</div>
