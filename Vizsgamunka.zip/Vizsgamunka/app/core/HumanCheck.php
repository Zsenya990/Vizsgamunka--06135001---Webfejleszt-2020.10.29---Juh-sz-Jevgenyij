<?php

declare(strict_types=1);

namespace App\Core;

final class HumanCheck
{
    public static function issue(): array
    {
        $left = random_int(2, 9);
        $right = random_int(1, 8);
        $operator = random_int(0, 1) === 1 ? '+' : '-';

        if ($operator === '-' && $right >= $left) {
            [$left, $right] = [$right + 1, $left - 1 > 0 ? $left - 1 : 1];
        }

        $answer = $operator === '+' ? $left + $right : $left - $right;
        $question = sprintf('Mennyi %d %s %d?', $left, $operator, $right);

        $_SESSION['human_check'] = [
            'question' => $question,
            'answer' => (string) $answer,
        ];

        return [
            'question' => $question,
        ];
    }

    public static function currentQuestion(): string
    {
        if (!isset($_SESSION['human_check']['question'])) {
            $challenge = self::issue();
            return (string) $challenge['question'];
        }

        return (string) $_SESSION['human_check']['question'];
    }

    public static function verify(string $answer): bool
    {
        $expected = (string) ($_SESSION['human_check']['answer'] ?? '');
        return $expected !== '' && hash_equals($expected, trim($answer));
    }

    public static function refresh(): array
    {
        return self::issue();
    }

    public static function clear(): void
    {
        unset($_SESSION['human_check']);
    }
}
