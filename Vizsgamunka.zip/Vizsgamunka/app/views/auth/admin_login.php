<div class="login-container">
    <div class="login-box">
        <h2>Admin bejelentkezes</h2>

        <?php if (!empty($error)): ?>
            <div class="alert">Hibas felhasznalonev vagy jelszo.</div>
        <?php endif; ?>

        <?php if (!empty($timedOut)): ?>
            <div class="alert">A munkamenet lejart, kerlek jelentkezz be ujra.</div>
        <?php endif; ?>

        <?php if (!empty($lockedOut)): ?>
            <div class="alert">Tul sok sikertelen probalkozas tortent. Probald ujra 5 perc mulva.</div>
        <?php endif; ?>

        <form method="POST" action="<?= htmlspecialchars(app_url('admin/login'), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string) ($csrfToken ?? ''), ENT_QUOTES, 'UTF-8') ?>">
            <div class="form-group">
                <label for="username">Felhasznalonev</label>
                <input type="text" id="username" name="username" required class="form-control">
            </div>

            <div class="form-group">
                <label for="password">Jelszo</label>
                <input type="password" id="password" name="password" required class="form-control">
            </div>

            <button type="submit" class="btn btn-primary">Bejelentkezes</button>
        </form>
    </div>
</div>
