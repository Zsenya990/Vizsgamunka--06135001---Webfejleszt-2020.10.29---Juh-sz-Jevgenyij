<?php if (!isset($timeslot) || empty($timeslot)): ?>
    <div class="p-4">
        <div class="alert alert-danger">A kert idosav nem talalhato.</div>
    </div>
<?php else: ?>
    <div class="modal-header">
        <h5 class="modal-title">Idosav szerkesztese</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
    </div>

    <div class="modal-body">
        <form id="updateTimeslotForm">
            <input type="hidden" name="id" value="<?= (int) $timeslot['id'] ?>">

            <div class="mb-3">
                <label class="form-label">Idopont</label>
                <input
                    type="datetime-local"
                    name="timeslot"
                    class="form-control"
                    value="<?= date('Y-m-d\TH:i', strtotime((string) $timeslot['timeslot'])) ?>"
                    required
                >
            </div>

            <button class="btn btn-primary w-100" type="submit">Mentes</button>
        </form>
    </div>
<?php endif; ?>
